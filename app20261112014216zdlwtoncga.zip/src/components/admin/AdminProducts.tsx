"use client";

import { useEffect, useState } from "react";
import { ImagePlus, Loader2, Pencil, Plus, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { upload } from "@zoerai/integration";
import { useAuth } from "@/components/AuthProvider";
import { formatEGP } from "@/lib/format";

type Variant = {
  id?: string;
  product_id?: string;
  size_label: string;
  volume_ml: number;
  price_egp: number;
  stock: number;
  is_active: boolean;
};

type Form = {
  id?: string;
  name: string;
  slug: string;
  description: string;
  category_id: string;
  gender: string;
  top_notes: string;
  heart_notes: string;
  base_notes: string;
  longevity: string;
  image_url: string;
  is_featured: boolean;
  is_best_seller: boolean;
  is_offer: boolean;
  discount_percent: number;
  is_active: boolean;
  variants: Variant[];
};

const EMPTY: Form = {
  name: "",
  slug: "",
  description: "",
  category_id: "",
  gender: "unisex",
  top_notes: "",
  heart_notes: "",
  base_notes: "",
  longevity: "",
  image_url: "",
  is_featured: false,
  is_best_seller: false,
  is_offer: false,
  discount_percent: 0,
  is_active: true,
  variants: [
    { size_label: "30 ML", volume_ml: 30, price_egp: 70, stock: 20, is_active: true },
    { size_label: "50 ML", volume_ml: 50, price_egp: 250, stock: 10, is_active: true },
    { size_label: "100 ML", volume_ml: 100, price_egp: 400, stock: 5, is_active: true },
  ],
};

export default function AdminProducts() {
  const { session } = useAuth();
  const [products, setProducts] = useState<any[]>([]);
  const [variants, setVariants] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [form, setForm] = useState<Form | null>(null);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);

  const load = async () => {
    if (!session) return;
    const res = await fetch("/api/admin/products", {
      headers: { Authorization: `Bearer ${session.access_token}` },
    });
    if (!res.ok) return;
    const data = await res.json();
    setProducts(data.products ?? []);
    setVariants(data.variants ?? []);
    setCategories(data.categories ?? []);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session]);

  const openEdit = (p: any) => {
    const own = variants.filter((v) => v.product_id === p.id);
    setForm({
      id: p.id,
      name: p.name ?? "",
      slug: p.slug ?? "",
      description: p.description ?? "",
      category_id: p.category_id ?? "",
      gender: p.gender ?? "unisex",
      top_notes: p.top_notes ?? "",
      heart_notes: p.heart_notes ?? "",
      base_notes: p.base_notes ?? "",
      longevity: p.longevity ?? "",
      image_url: p.image_url ?? "",
      is_featured: !!p.is_featured,
      is_best_seller: !!p.is_best_seller,
      is_offer: !!p.is_offer,
      discount_percent: p.discount_percent ?? 0,
      is_active: p.is_active ?? true,
      variants:
        own.length > 0
          ? own.map((v) => ({
              id: v.id,
              size_label: v.size_label,
              volume_ml: v.volume_ml,
              price_egp: Number(v.price_egp),
              stock: v.stock,
              is_active: v.is_active,
            }))
          : EMPTY.variants,
    });
  };

  const handleUpload = async (file: File) => {
    setUploading(true);
    try {
      const result = await upload.uploadWithPresignedUrl(file, {
        maxSize: 5 * 1024 * 1024,
        allowedExtensions: [".jpg", ".jpeg", ".png", ".webp"],
        onProgress: (p) => setUploading(true),
      });
      if (!result.success || !result.url) {
        toast.error(result.error ?? "تعذر رفع الصورة");
        return;
      }
      setForm((f) => (f ? { ...f, image_url: result.url! } : f));
      toast.success("تم رفع الصورة");
    } catch {
      toast.error("تعذر رفع الصورة");
    } finally {
      setUploading(false);
    }
  };

  const save = async () => {
    if (!form || !session) return;
    if (!form.name.trim() || !form.slug.trim()) {
      toast.error("الاسم والرابط المختصر مطلوبان");
      return;
    }
    setBusy(true);
    const res = await fetch("/api/admin/products", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify(form),
    });
    setBusy(false);
    if (res.ok) {
      toast.success(form.id ? "تم تحديث المنتج" : "تمت إضافة المنتج");
      setForm(null);
      load();
    } else {
      const data = await res.json();
      toast.error(data.error ?? "تعذر الحفظ");
    }
  };

  const remove = async (id: string) => {
    if (!session) return;
    if (!confirm("هل تريد حذف هذا المنتج نهائيًا؟")) return;
    const res = await fetch(`/api/admin/products?id=${id}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${session.access_token}` },
    });
    if (res.ok) {
      toast.success("تم حذف المنتج");
      load();
    } else {
      toast.error("تعذر الحذف");
    }
  };

  const updateVariant = (index: number, patch: Partial<Variant>) => {
    setForm((f) => {
      if (!f) return f;
      const next = [...f.variants];
      next[index] = { ...next[index], ...patch };
      return { ...f, variants: next };
    });
  };

  return (
    <div className="space-y-5">
      <div className="flex justify-end">
        <button
          onClick={() => setForm({ ...EMPTY, variants: EMPTY.variants.map((v) => ({ ...v })) })}
          className="inline-flex items-center gap-2 rounded-full bg-secondary px-5 py-2.5 text-xs font-bold text-secondary-foreground transition hover:bg-primary hover:text-primary-foreground"
        >
          <Plus className="h-4 w-4" />
          إضافة عطر جديد
        </button>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-border bg-card">
        <table className="w-full min-w-[760px] text-right text-sm">
          <thead className="bg-muted/50 text-xs text-muted-foreground">
            <tr>
              <th className="p-3">الصورة</th>
              <th className="p-3">الاسم</th>
              <th className="p-3">الأسعار</th>
              <th className="p-3">المخزون</th>
              <th className="p-3">الحالة</th>
              <th className="p-3">إجراءات</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => {
              const own = variants.filter((v) => v.product_id === p.id);
              const stock = own.reduce((s, v) => s + Number(v.stock ?? 0), 0);
              return (
                <tr key={p.id} className="border-t border-border">
                  <td className="p-3">
                    <div className="h-12 w-10 overflow-hidden rounded-lg bg-muted">
                      {p.image_url && (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={p.image_url} alt={p.name} className="h-full w-full object-cover" />
                      )}
                    </div>
                  </td>
                  <td className="p-3">
                    <p className="font-bold">{p.name}</p>
                    <p dir="ltr" className="text-right text-[11px] text-muted-foreground">
                      {p.slug}
                    </p>
                  </td>
                  <td className="p-3 text-xs">
                    {own.map((v) => (
                      <div key={v.id}>
                        {v.size_label}: {formatEGP(v.price_egp)}
                      </div>
                    ))}
                  </td>
                  <td className="p-3">
                    <span
                      className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${
                        stock <= 10 ? "bg-destructive/10 text-destructive" : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {stock} قطعة
                    </span>
                  </td>
                  <td className="p-3 text-xs">
                    {p.is_active ? "معروض" : "مخفي"}
                    {p.discount_percent > 0 && (
                      <span className="mr-2 rounded-full bg-primary/15 px-2 py-0.5 text-[11px] font-bold text-primary">
                        -{p.discount_percent}%
                      </span>
                    )}
                  </td>
                  <td className="p-3">
                    <div className="flex gap-1">
                      <button
                        onClick={() => openEdit(p)}
                        className="rounded-full border border-border p-2 transition hover:border-primary"
                        aria-label="تعديل"
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => remove(p.id)}
                        className="rounded-full border border-border p-2 text-destructive transition hover:bg-destructive/10"
                        aria-label="حذف"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {form && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 p-4" role="dialog" aria-modal="true">
          <div className="mx-auto my-8 max-w-3xl rounded-2xl border border-border bg-card p-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-extrabold">
                {form.id ? "تعديل المنتج" : "إضافة عطر جديد"}
              </h2>
              <button onClick={() => setForm(null)} aria-label="إغلاق" className="rounded-full p-2 hover:bg-muted">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-5 grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-sm font-semibold">اسم العطر *</label>
                <input
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm outline-none focus:border-primary"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-semibold">الرابط المختصر *</label>
                <input
                  dir="ltr"
                  value={form.slug}
                  onChange={(e) => setForm({ ...form, slug: e.target.value })}
                  className="w-full rounded-xl border border-input bg-background px-4 py-2 text-right text-sm outline-none focus:border-primary"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="mb-1.5 block text-sm font-semibold">الوصف</label>
                <textarea
                  rows={3}
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  className="w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm outline-none focus:border-primary"
                />
              </div>

              <div>
                <label className="mb-1.5 block text-sm font-semibold">الفئة</label>
                <select
                  value={form.category_id}
                  onChange={(e) => setForm({ ...form, category_id: e.target.value })}
                  className="w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm outline-none focus:border-primary"
                >
                  <option value="">بدون فئة</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="mb-1.5 block text-sm font-semibold">النوع</label>
                <select
                  value={form.gender}
                  onChange={(e) => setForm({ ...form, gender: e.target.value })}
                  className="w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm outline-none focus:border-primary"
                >
                  <option value="men">رجالي</option>
                  <option value="women">نسائي</option>
                  <option value="unisex">مشترك</option>
                  <option value="luxury">فاخر</option>
                </select>
              </div>

              <div>
                <label className="mb-1.5 block text-sm font-semibold">النفحات العلوية</label>
                <input
                  value={form.top_notes}
                  onChange={(e) => setForm({ ...form, top_notes: e.target.value })}
                  className="w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm outline-none focus:border-primary"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-semibold">نفحات القلب</label>
                <input
                  value={form.heart_notes}
                  onChange={(e) => setForm({ ...form, heart_notes: e.target.value })}
                  className="w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm outline-none focus:border-primary"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-semibold">النفحات القاعدية</label>
                <input
                  value={form.base_notes}
                  onChange={(e) => setForm({ ...form, base_notes: e.target.value })}
                  className="w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm outline-none focus:border-primary"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-semibold">مدة الثبات</label>
                <input
                  value={form.longevity}
                  onChange={(e) => setForm({ ...form, longevity: e.target.value })}
                  placeholder="8-10 ساعات"
                  className="w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm outline-none focus:border-primary"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="mb-1.5 block text-sm font-semibold">صورة المنتج</label>
                <div className="flex flex-wrap items-center gap-3">
                  <div className="h-24 w-20 overflow-hidden rounded-xl bg-muted">
                    {form.image_url && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={form.image_url} alt={form.name} className="h-full w-full object-cover" />
                    )}
                  </div>
                  <label className="inline-flex cursor-pointer items-center gap-2 rounded-full border border-border px-4 py-2 text-xs font-bold transition hover:border-primary">
                    {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-4 w-4" />}
                    رفع صورة
                    <input
                      type="file"
                      accept=".jpg,.jpeg,.png,.webp"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleUpload(file);
                      }}
                    />
                  </label>
                  <input
                    dir="ltr"
                    value={form.image_url}
                    onChange={(e) => setForm({ ...form, image_url: e.target.value })}
                    placeholder="أو ألصق رابط الصورة"
                    className="min-w-60 flex-1 rounded-xl border border-input bg-background px-3 py-2 text-right text-xs outline-none focus:border-primary"
                  />
                </div>
              </div>
            </div>

            <div className="mt-6">
              <h3 className="text-sm font-extrabold">الأحجام والأسعار والمخزون</h3>
              <p className="mt-1 text-xs text-muted-foreground">
                القيم الافتراضية: ٣٠ مل = ٧٠ ج.م، ٥٠ مل = ٢٥٠ ج.م، ١٠٠ مل = ٤٠٠ ج.م
              </p>
              <div className="mt-3 space-y-2">
                {form.variants.map((v, i) => (
                  <div
                    key={i}
                    className="grid grid-cols-2 items-center gap-2 rounded-xl border border-border p-3 sm:grid-cols-5"
                  >
                    <input
                      value={v.size_label}
                      onChange={(e) => updateVariant(i, { size_label: e.target.value })}
                      className="rounded-lg border border-input bg-background px-3 py-2 text-xs outline-none focus:border-primary"
                      placeholder="الحجم"
                    />
                    <input
                      type="number"
                      dir="ltr"
                      value={v.volume_ml}
                      onChange={(e) => updateVariant(i, { volume_ml: Number(e.target.value) })}
                      className="rounded-lg border border-input bg-background px-3 py-2 text-right text-xs outline-none focus:border-primary"
                      placeholder="مل"
                    />
                    <input
                      type="number"
                      dir="ltr"
                      value={v.price_egp}
                      onChange={(e) => updateVariant(i, { price_egp: Number(e.target.value) })}
                      className="rounded-lg border border-input bg-background px-3 py-2 text-right text-xs outline-none focus:border-primary"
                      placeholder="السعر"
                    />
                    <input
                      type="number"
                      dir="ltr"
                      value={v.stock}
                      onChange={(e) => updateVariant(i, { stock: Number(e.target.value) })}
                      className="rounded-lg border border-input bg-background px-3 py-2 text-right text-xs outline-none focus:border-primary"
                      placeholder="المخزون"
                    />
                    <button
                      onClick={() =>
                        setForm({ ...form, variants: form.variants.filter((_, idx) => idx !== i) })
                      }
                      className="inline-flex items-center justify-center gap-1 rounded-lg border border-border px-3 py-2 text-xs text-destructive transition hover:bg-destructive/10"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      حذف
                    </button>
                  </div>
                ))}
                <button
                  onClick={() =>
                    setForm({
                      ...form,
                      variants: [
                        ...form.variants,
                        {
                          size_label: "",
                          volume_ml: 0,
                          price_egp: 0,
                          stock: 0,
                          is_active: true,
                        },
                      ],
                    })
                  }
                  className="inline-flex items-center gap-1.5 rounded-full border border-border px-4 py-2 text-xs font-bold transition hover:border-primary"
                >
                  <Plus className="h-3.5 w-3.5" />
                  إضافة حجم
                </button>
              </div>
            </div>

            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <div className="rounded-xl border border-border p-4">
                <label className="mb-1.5 block text-sm font-semibold">نسبة الخصم %</label>
                <input
                  type="number"
                  dir="ltr"
                  value={form.discount_percent}
                  onChange={(e) => setForm({ ...form, discount_percent: Number(e.target.value) })}
                  className="w-full rounded-xl border border-input bg-background px-4 py-2.5 text-right text-sm outline-none focus:border-primary"
                />
              </div>
              <div className="flex flex-col justify-center gap-2 rounded-xl border border-border p-4">
                {[
                  { key: "is_featured" as const, label: "عطر مميز" },
                  { key: "is_best_seller" as const, label: "الأكثر مبيعًا" },
                  { key: "is_offer" as const, label: "ضمن العروض" },
                  { key: "is_active" as const, label: "معروض في المتجر" },
                ].map((f) => (
                  <label key={f.key} className="flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={form[f.key]}
                      onChange={(e) => setForm({ ...form, [f.key]: e.target.checked })}
                      className="h-4 w-4 accent-[#c6a15b]"
                    />
                    {f.label}
                  </label>
                ))}
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-3">
              <button
                onClick={() => setForm(null)}
                className="rounded-full border border-border px-5 py-2.5 text-sm font-bold transition hover:border-primary"
              >
                إلغاء
              </button>
              <button
                onClick={save}
                disabled={busy}
                className="inline-flex items-center gap-2 rounded-full bg-secondary px-6 py-2.5 text-sm font-bold text-secondary-foreground transition hover:bg-primary hover:text-primary-foreground disabled:opacity-60"
              >
                {busy && <Loader2 className="h-4 w-4 animate-spin" />}
                حفظ
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
