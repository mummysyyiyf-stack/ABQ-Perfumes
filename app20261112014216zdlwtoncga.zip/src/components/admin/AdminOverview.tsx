"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { AlertTriangle, DollarSign, Package, ShoppingCart, TrendingUp } from "lucide-react";
import { useAuth } from "@/components/AuthProvider";
import { formatEGP } from "@/lib/format";
import { ORDER_STATUS_LABELS } from "@/lib/types";

type Stats = {
  revenue: number;
  orderCount: number;
  validOrderCount: number;
  averageOrder: number;
  byStatus: Record<string, number>;
  daily: Array<{ date: string; total: number }>;
  topProducts: Array<{ name: string; qty: number; revenue: number }>;
  lowStock: Array<{ id: string; name: string; size: string; stock: number }>;
};

export default function AdminOverview() {
  const { session } = useAuth();
  const [stats, setStats] = useState<Stats | null>(null);
  const [recent, setRecent] = useState<any[]>([]);

  useEffect(() => {
    if (!session) return;
    const headers = { Authorization: `Bearer ${session.access_token}` };

    const load = async () => {
      const [s, o] = await Promise.all([
        fetch("/api/admin/stats", { headers }),
        fetch("/api/admin/orders", { headers }),
      ]);
      if (s.ok) setStats(await s.json());
      if (o.ok) {
        const data = await o.json();
        setRecent((data.orders ?? []).slice(0, 6));
      }
    };
    load();
  }, [session]);

  if (!stats) {
    return <p className="py-16 text-center text-sm text-muted-foreground">جارٍ تحميل الإحصائيات...</p>;
  }

  const maxDaily = Math.max(...stats.daily.map((d) => d.total), 1);

  const cards = [
    { label: "إجمالي الإيراد", value: formatEGP(stats.revenue), icon: DollarSign },
    { label: "عدد الطلبات", value: String(stats.orderCount), icon: ShoppingCart },
    { label: "متوسط قيمة الطلب", value: formatEGP(stats.averageOrder), icon: TrendingUp },
    { label: "طلبات تم تأكيدها", value: String(stats.byStatus.confirmed ?? 0), icon: Package },
  ];

  return (
    <div className="space-y-8">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center justify-between">
              <p className="text-xs font-semibold text-muted-foreground">{c.label}</p>
              <c.icon className="h-4 w-4 text-primary" />
            </div>
            <p className="mt-3 text-2xl font-extrabold">{c.value}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-2xl border border-border bg-card p-5">
          <h2 className="font-extrabold">المبيعات خلال ٧ أيام</h2>
          <div className="mt-6 flex h-48 items-end gap-2">
            {stats.daily.map((d) => (
              <div key={d.date} className="flex flex-1 flex-col items-center gap-2">
                <span className="text-[10px] text-muted-foreground">
                  {formatEGP(d.total).replace(" ج.م", "")}
                </span>
                <div
                  className="w-full rounded-t-lg bg-primary/80 transition hover:bg-primary"
                  style={{ height: `${Math.max(6, (d.total / maxDaily) * 140)}px` }}
                  title={d.date}
                />
                <span className="text-[10px] text-muted-foreground">{d.date.slice(5)}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-2xl border border-border bg-card p-5">
          <h2 className="font-extrabold">توزيع حالات الطلبات</h2>
          <div className="mt-5 space-y-3">
            {Object.entries(stats.byStatus).map(([status, count]) => (
              <div key={status} className="flex items-center gap-3">
                <span className="w-24 shrink-0 text-xs font-semibold">
                  {ORDER_STATUS_LABELS[status as keyof typeof ORDER_STATUS_LABELS] ?? status}
                </span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full rounded-full bg-primary"
                    style={{
                      width: `${stats.orderCount ? (count / stats.orderCount) * 100 : 0}%`,
                    }}
                  />
                </div>
                <span className="w-8 text-left text-xs font-bold">{count}</span>
              </div>
            ))}
          </div>
        </section>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-2xl border border-border bg-card p-5">
          <h2 className="font-extrabold">الأكثر مبيعًا</h2>
          {stats.topProducts.length === 0 ? (
            <p className="mt-4 text-xs text-muted-foreground">لا توجد مبيعات بعد.</p>
          ) : (
            <ul className="mt-4 space-y-3">
              {stats.topProducts.map((p, i) => (
                <li key={p.name} className="flex items-center gap-3 text-sm">
                  <span className="flex h-7 w-7 items-center justify-center rounded-full bg-secondary text-xs font-bold text-primary">
                    {i + 1}
                  </span>
                  <span className="flex-1 font-semibold">{p.name}</span>
                  <span className="text-xs text-muted-foreground">{p.qty} قطعة</span>
                  <span className="w-24 text-left font-bold text-primary">
                    {formatEGP(p.revenue)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="rounded-2xl border border-border bg-card p-5">
          <h2 className="flex items-center gap-2 font-extrabold">
            <AlertTriangle className="h-4 w-4 text-destructive" />
            منتجات منخفضة المخزون
          </h2>
          {stats.lowStock.length === 0 ? (
            <p className="mt-4 text-xs text-muted-foreground">المخزون في وضع جيد.</p>
          ) : (
            <ul className="mt-4 space-y-2 text-sm">
              {stats.lowStock.map((v) => (
                <li
                  key={v.id}
                  className="flex items-center justify-between rounded-xl border border-border px-3 py-2"
                >
                  <span className="font-semibold">
                    {v.name} <span className="text-xs text-muted-foreground">{v.size}</span>
                  </span>
                  <span className="text-xs font-bold text-destructive">{v.stock} متبقي</span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <section className="rounded-2xl border border-border bg-card p-5">
        <div className="flex items-center justify-between">
          <h2 className="font-extrabold">أحدث الطلبات</h2>
          <Link href="/admin/orders" className="text-xs font-bold text-primary hover:underline">
            عرض الكل
          </Link>
        </div>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[600px] text-right text-sm">
            <thead className="text-xs text-muted-foreground">
              <tr className="border-b border-border">
                <th className="p-2">رقم الطلب</th>
                <th className="p-2">العميل</th>
                <th className="p-2">المدينة</th>
                <th className="p-2">الإجمالي</th>
                <th className="p-2">الحالة</th>
              </tr>
            </thead>
            <tbody>
              {recent.map((o) => (
                <tr key={o.id} className="border-b border-border/60">
                  <td dir="ltr" className="p-2 text-right font-mono text-xs">{o.order_number}</td>
                  <td className="p-2 font-semibold">{o.customer_name}</td>
                  <td className="p-2 text-muted-foreground">{o.city}</td>
                  <td className="p-2 font-bold text-primary">{formatEGP(o.total)}</td>
                  <td className="p-2 text-xs">
                    {ORDER_STATUS_LABELS[o.status as keyof typeof ORDER_STATUS_LABELS]}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
