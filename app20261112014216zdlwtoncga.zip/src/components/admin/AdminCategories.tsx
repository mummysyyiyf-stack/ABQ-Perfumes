"use client";

import { useEffect, useState } from "react";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/components/AuthProvider";

export default function AdminCategories() {
  const { session } = useAuth();
  const [categories, setCategories] = useState<any[]>([]);
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [busy, setBusy] = useState(false);

  const load = async () => {
    if (!session) return;
    const res = await fetch("/api/admin/products", {
      headers: { Authorization: `Bearer ${session.access_token}` },
    });
    if (res.ok) {
      const data = await res.json();
      setCategories(data.categories ?? []);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session]);

  const add = async () => {
    if (!session || !name.trim()) {
      toast.error("اسم الفئة مطلوب");
      return;
    }
    setBusy(true);
    const res = await fetch("/api/admin/categories", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify({
        name,
        slug: slug.trim() || name.trim().toLowerCase().replace(/\s+/g, "-"),
      }),
    });
    setBusy(false);
    if (res.ok) {
      toast.success("تمت إضافة الفئة");
      setName("");
      setSlug("");
      load();
    } else {
      const data = await res.json();
      toast.error(data.error ?? "تعذر إضافة الفئة");
    }
  };

  const remove = async (id: string) => {
    if (!session) return;
    if (!confirm("حذف هذه الفئة؟")) return;
    const res = await fetch(`/api/admin/categories?id=${id}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${session.access_token}` },
    });
    if (res.ok) {
      toast.success("تم حذف الفئة");
      load();
    } else {
      toast.error("تعذر الحذف");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-3 rounded-2xl border border-border bg-card p-5">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="اسم الفئة"
          className="flex-1 rounded-xl border border-input bg-background px-4 py-2.5 text-sm outline-none focus:border-primary"
        />
        <input
          dir="ltr"
          value={slug}
          onChange={(e) => setSlug(e.target.value)}
          placeholder="slug"
          className="w-40 rounded-xl border border-input bg-background px-4 py-2.5 text-right text-sm outline-none focus:border-primary"
        />
        <button
          onClick={add}
          disabled={busy}
          className="inline-flex items-center gap-2 rounded-full bg-secondary px-5 py-2.5 text-xs font-bold text-secondary-foreground transition hover:bg-primary hover:text-primary-foreground disabled:opacity-60"
        >
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
          إضافة فئة
        </button>
      </div>

      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <table className="w-full text-right text-sm">
          <thead className="bg-muted/50 text-xs text-muted-foreground">
            <tr>
              <th className="p-3">الاسم</th>
              <th className="p-3">الرابط</th>
              <th className="p-3">الترتيب</th>
              <th className="p-3"></th>
            </tr>
          </thead>
          <tbody>
            {categories.map((c) => (
              <tr key={c.id} className="border-t border-border">
                <td className="p-3 font-bold">{c.name}</td>
                <td dir="ltr" className="p-3 text-right text-xs text-muted-foreground">{c.slug}</td>
                <td className="p-3 text-xs text-muted-foreground">{c.sort_order}</td>
                <td className="p-3 text-left">
                  <button
                    onClick={() => remove(c.id)}
                    className="inline-flex rounded-full border border-border p-2 text-destructive transition hover:bg-destructive/10"
                    aria-label="حذف"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
