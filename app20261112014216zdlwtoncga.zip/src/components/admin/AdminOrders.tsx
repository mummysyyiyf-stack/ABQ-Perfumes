"use client";

import { useEffect, useState } from "react";
import { ChevronDown, Loader2, RefreshCw, Search } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/components/AuthProvider";
import { formatEGP, formatDate } from "@/lib/format";
import { ORDER_STATUS_LABELS, type OrderStatus } from "@/lib/types";

const STATUSES: OrderStatus[] = ["new", "confirmed", "shipped", "delivered", "cancelled"];

export default function AdminOrders() {
  const { session } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [items, setItems] = useState<any[]>([]);
  const [filter, setFilter] = useState<"all" | OrderStatus>("all");
  const [search, setSearch] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);

  const load = async () => {
    if (!session) return;
    setLoading(true);
    const res = await fetch(`/api/admin/orders?status=${filter}`, {
      headers: { Authorization: `Bearer ${session.access_token}` },
    });
    if (res.ok) {
      const data = await res.json();
      setOrders(data.orders ?? []);
      setItems(data.items ?? []);
    }
    setLoading(false);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, filter]);

  const updateStatus = async (orderId: string, status: OrderStatus) => {
    if (!session) return;
    setBusy(orderId);
    const res = await fetch("/api/admin/orders", {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify({ orderId, status }),
    });
    setBusy(null);
    if (res.ok) {
      toast.success("تم تحديث حالة الطلب");
      load();
    } else {
      toast.error("تعذر تحديث الطلب");
    }
  };

  const filtered = orders.filter(
    (o) =>
      !search ||
      o.order_number?.toLowerCase().includes(search.toLowerCase()) ||
      o.customer_name?.includes(search) ||
      o.phone?.includes(search) ||
      o.city?.includes(search),
  );

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-2">
        <button
          onClick={() => setFilter("all")}
          className={`rounded-full border px-4 py-2 text-xs font-bold transition ${
            filter === "all" ? "border-primary bg-primary text-primary-foreground" : "border-border"
          }`}
        >
          الكل ({orders.length})
        </button>
        {STATUSES.map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`rounded-full border px-4 py-2 text-xs font-bold transition ${
              filter === s ? "border-primary bg-primary text-primary-foreground" : "border-border"
            }`}
          >
            {ORDER_STATUS_LABELS[s]}
          </button>
        ))}
        <button
          onClick={load}
          className="mr-auto inline-flex items-center gap-1.5 rounded-full border border-border px-3 py-2 text-xs font-bold transition hover:border-primary"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          تحديث
        </button>
      </div>

      <div className="flex items-center gap-2 rounded-full border border-border bg-card px-4 py-2">
        <Search className="h-4 w-4 text-muted-foreground" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="ابحث برقم الطلب أو اسم العميل أو الهاتف"
          className="w-full bg-transparent text-sm outline-none"
        />
      </div>

      {loading ? (
        <p className="py-16 text-center text-sm text-muted-foreground">جارٍ التحميل...</p>
      ) : filtered.length === 0 ? (
        <p className="py-16 text-center text-sm text-muted-foreground">لا توجد طلبات.</p>
      ) : (
        <div className="space-y-3">
          {filtered.map((o) => {
            const orderItems = items.filter((i) => i.order_id === o.id);
            const open = expanded === o.id;
            return (
              <div key={o.id} className="overflow-hidden rounded-2xl border border-border bg-card">
                <button
                  onClick={() => setExpanded(open ? null : o.id)}
                  className="flex w-full flex-wrap items-center gap-4 p-4 text-right"
                >
                  <div className="min-w-40 flex-1">
                    <p dir="ltr" className="text-right font-mono text-xs text-muted-foreground">
                      {o.order_number}
                    </p>
                    <p className="mt-1 font-extrabold">{o.customer_name}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {o.phone} · {o.city} · {formatDate(o.created_at)}
                    </p>
                  </div>
                  <p className="font-extrabold text-primary">{formatEGP(o.total)}</p>
                  <span className="rounded-full bg-muted px-3 py-1 text-xs font-bold">
                    {ORDER_STATUS_LABELS[o.status as OrderStatus]}
                  </span>
                  <ChevronDown
                    className={`h-4 w-4 transition ${open ? "rotate-180" : ""}`}
                  />
                </button>

                {open && (
                  <div className="border-t border-border bg-muted/30 p-4">
                    <div className="grid gap-4 text-xs sm:grid-cols-3">
                      <div>
                        <p className="font-bold text-muted-foreground">العنوان</p>
                        <p className="mt-1 leading-6">{o.address}</p>
                        <p>{o.city}</p>
                      </div>
                      <div>
                        <p className="font-bold text-muted-foreground">الدفع</p>
                        <p className="mt-1">الدفع عند الاستلام</p>
                        <p className="mt-1">
                          الفرعي: {formatEGP(o.subtotal)} · التوصيل: {formatEGP(o.delivery_fee)}
                        </p>
                      </div>
                      <div>
                        <p className="font-bold text-muted-foreground">ملاحظات</p>
                        <p className="mt-1 leading-6">{o.notes || "—"}</p>
                      </div>
                    </div>

                    <div className="mt-4 overflow-hidden rounded-xl border border-border bg-background">
                      {orderItems.map((i) => (
                        <div
                          key={i.id}
                          className="flex items-center justify-between gap-3 border-b border-border px-3 py-2 text-xs last:border-0"
                        >
                          <span className="font-semibold">
                            {i.product_name}{" "}
                            <span className="text-muted-foreground">
                              {i.variant_label} × {i.quantity}
                            </span>
                          </span>
                          <span className="font-bold">{formatEGP(i.line_total)}</span>
                        </div>
                      ))}
                    </div>

                    <div className="mt-4 flex flex-wrap items-center gap-2">
                      <span className="text-xs font-bold text-muted-foreground">تغيير الحالة:</span>
                      {STATUSES.map((s) => (
                        <button
                          key={s}
                          disabled={busy === o.id || o.status === s}
                          onClick={() => updateStatus(o.id, s)}
                          className={`rounded-full border px-3 py-1.5 text-[11px] font-bold transition disabled:opacity-50 ${
                            o.status === s
                              ? "border-primary bg-primary text-primary-foreground"
                              : "border-border hover:border-primary"
                          }`}
                        >
                          {ORDER_STATUS_LABELS[s]}
                        </button>
                      ))}
                      {busy === o.id && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
