"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Loader2, Package } from "lucide-react";
import { useAuth } from "@/components/AuthProvider";
import { supabase } from "@/integrations/supabase/client";
import { formatEGP, formatDate } from "@/lib/format";
import { ORDER_STATUS_LABELS, type OrderStatus } from "@/lib/types";

export default function CustomerOrders() {
  const { user, loading } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [items, setItems] = useState<any[]>([]);
  const [busy, setBusy] = useState(true);

  useEffect(() => {
    if (loading) return;
    if (!user) {
      setBusy(false);
      return;
    }
    const load = async () => {
      const { data } = await supabase
        .from("orders")
        .select(
          "id,order_number,customer_name,phone,address,city,subtotal,delivery_fee,total,payment_method,status,created_at",
        )
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(50);
      const list = data ?? [];
      setOrders(list);
      if (list.length > 0) {
        const { data: it } = await supabase
          .from("order_items")
          .select("id,order_id,product_name,variant_label,quantity,line_total")
          .in("order_id", list.map((o) => o.id));
        setItems(it ?? []);
      }
      setBusy(false);
    };
    load();
  }, [user, loading]);

  if (loading || busy) {
    return (
      <p className="flex items-center justify-center gap-2 py-16 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" />
        جارٍ التحميل...
      </p>
    );
  }

  if (!user) {
    return (
      <div className="rounded-2xl border border-dashed border-border p-16 text-center">
        <p className="text-lg font-bold">سجّل الدخول لعرض طلباتك</p>
        <Link
          href="/account?mode=login"
          className="mt-6 inline-block rounded-full bg-secondary px-7 py-3 text-sm font-bold text-secondary-foreground"
        >
          تسجيل الدخول
        </Link>
      </div>
    );
  }

  if (orders.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-border p-16 text-center">
        <Package className="mx-auto h-14 w-14 text-muted-foreground/30" />
        <p className="mt-4 text-lg font-bold">لا توجد طلبات بعد</p>
        <p className="mt-2 text-sm text-muted-foreground">
          سجّل الدخول مرة أخرى بعد إتمام أول طلب لتابعته هنا.
        </p>
        <Link
          href="/products"
          className="mt-7 inline-block rounded-full bg-secondary px-7 py-3 text-sm font-bold text-secondary-foreground"
        >
          تصفح العطور
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {orders.map((o) => {
        const own = items.filter((i) => i.order_id === o.id);
        return (
          <div key={o.id} className="rounded-2xl border border-border bg-card p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p dir="ltr" className="text-right font-mono text-xs text-muted-foreground">
                  {o.order_number}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">{formatDate(o.created_at)}</p>
              </div>
              <span className="rounded-full bg-muted px-3 py-1 text-xs font-bold">
                {ORDER_STATUS_LABELS[o.status as OrderStatus]}
              </span>
              <p className="font-extrabold text-primary">{formatEGP(o.total)}</p>
            </div>
            <div className="mt-3 space-y-1.5 border-t border-border pt-3">
              {own.map((i) => (
                <div key={i.id} className="flex justify-between text-xs">
                  <span className="text-muted-foreground">
                    {i.product_name} — {i.variant_label} × {i.quantity}
                  </span>
                  <span className="font-bold">{formatEGP(i.line_total)}</span>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
