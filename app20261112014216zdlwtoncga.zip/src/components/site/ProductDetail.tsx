"use client";

import Link from "next/link";
import { useState } from "react";
import { Check, Heart, Minus, Plus, ShoppingBag, Star, Truck } from "lucide-react";
import { toast } from "sonner";
import { useCart } from "@/components/CartProvider";
import { formatEGP } from "@/lib/format";
import type { Product, ProductVariant } from "@/lib/types";

export default function ProductDetail({
  product,
  variants,
}: {
  product: Product;
  variants: ProductVariant[];
}) {
  const { addLine } = useCart();
  const [variantId, setVariantId] = useState(variants[0]?.id ?? "");
  const [qty, setQty] = useState(1);
  const [wish, setWish] = useState(false);

  const selected = variants.find((v) => v.id === variantId);
  const base = selected?.price_egp ?? 0;
  const price = product.discount_percent
    ? Math.round(base * (1 - product.discount_percent / 100))
    : base;
  const maxQty = Math.max(selected?.stock ?? 1, 1);

  const handleAdd = () => {
    if (!selected) return;
    if (selected.stock <= 0) {
      toast.error("هذا الحجم غير متوفر حاليًا");
      return;
    }
    addLine(
      {
        productId: product.id,
        variantId: selected.id,
        name: product.name,
        sizeLabel: selected.size_label,
        price,
        imageUrl: product.image_url,
        stock: selected.stock,
      },
      qty,
    );
    toast.success("تمت إضافة العطر إلى السلة");
  };

  const notes = [
    { label: "النفحات العلوية", value: product.top_notes },
    { label: "نفحات القلب", value: product.heart_notes },
    { label: "النفحات القاعدية", value: product.base_notes },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <nav className="text-xs text-muted-foreground">
        <Link href="/" className="hover:text-primary">الرئيسية</Link> /{" "}
        <Link href="/products" className="hover:text-primary">العطور</Link> /{" "}
        <span className="text-foreground">{product.name}</span>
      </nav>

      <div className="mt-6 grid gap-10 lg:grid-cols-2">
        <div className="relative overflow-hidden rounded-3xl border border-border bg-muted">
          {product.image_url && (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={product.image_url}
              alt={`عطر ${product.name} من ABQ`}
              className="aspect-[4/5] w-full object-cover"
            />
          )}
          {product.discount_percent > 0 && (
            <span className="absolute right-4 top-4 rounded-full bg-primary px-3 py-1 text-xs font-bold text-primary-foreground">
              خصم {product.discount_percent}%
            </span>
          )}
        </div>

        <div className="flex flex-col">
          <p className="text-xs uppercase tracking-[0.35em] text-muted-foreground">ABQ</p>
          <h1 className="mt-2 text-3xl font-extrabold leading-tight md:text-4xl">
            {product.name}
          </h1>

          <div className="mt-3 flex items-center gap-2 text-sm">
            <div className="flex">
              {[1, 2, 3, 4, 5].map((i) => (
                <Star
                  key={i}
                  className={`h-4 w-4 ${
                    i <= Math.round(Number(product.rating ?? 0))
                      ? "fill-primary text-primary"
                      : "text-muted-foreground/40"
                  }`}
                />
              ))}
            </div>
            <span className="font-bold">{product.rating ?? 0}</span>
            <span className="text-muted-foreground">({product.review_count ?? 0} تقييم)</span>
          </div>

          <p className="mt-5 text-sm leading-7 text-muted-foreground">{product.description}</p>

          {product.longevity && (
            <p className="mt-3 inline-block w-fit rounded-full bg-muted px-4 py-1.5 text-xs font-semibold">
              مدة الثبات: {product.longevity}
            </p>
          )}

          <div className="mt-7">
            <p className="mb-2 text-sm font-bold">اختر الحجم</p>
            <div className="grid gap-2 sm:grid-cols-3">
              {variants.map((v) => (
                <button
                  key={v.id}
                  type="button"
                  onClick={() => setVariantId(v.id)}
                  disabled={v.stock <= 0}
                  className={`rounded-2xl border p-4 text-right transition ${
                    variantId === v.id
                      ? "border-primary bg-primary/10"
                      : "border-border hover:border-primary/60"
                  } ${v.stock <= 0 ? "opacity-45" : ""}`}
                >
                  <p className="font-[family-name:var(--font-playfair)] text-lg font-bold">
                    {v.size_label}
                  </p>
                  <p className="mt-1 text-sm font-bold text-primary">
                    {formatEGP(v.price_egp)}
                  </p>
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    {v.stock > 0 ? `متوفر: ${v.stock}` : "غير متوفر"}
                  </p>
                </button>
              ))}
            </div>
          </div>

          <div className="mt-7 rounded-2xl border border-border bg-card p-5">
            <div className="flex items-end justify-between">
              <div>
                {selected && product.discount_percent > 0 && (
                  <span className="text-sm text-muted-foreground line-through">
                    {formatEGP(selected.price_egp)}
                  </span>
                )}
                <p className="text-3xl font-extrabold text-primary">{formatEGP(price)}</p>
              </div>
              <div className="flex items-center gap-2 rounded-full border border-border px-2 py-1">
                <button
                  type="button"
                  onClick={() => setQty((q) => Math.min(q + 1, maxQty))}
                  className="rounded-full p-1 transition hover:bg-muted"
                  aria-label="زيادة الكمية"
                >
                  <Plus className="h-4 w-4" />
                </button>
                <span className="w-6 text-center text-sm font-bold">{qty}</span>
                <button
                  type="button"
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  className="rounded-full p-1 transition hover:bg-muted"
                  aria-label="تقليل الكمية"
                >
                  <Minus className="h-4 w-4" />
                </button>
              </div>
            </div>

            <div className="mt-4 flex gap-2">
              <button
                type="button"
                onClick={handleAdd}
                disabled={!selected || selected.stock <= 0}
                className="flex flex-1 items-center justify-center gap-2 rounded-full bg-secondary px-6 py-3 text-sm font-bold text-secondary-foreground transition hover:bg-primary hover:text-primary-foreground disabled:opacity-50"
              >
                <ShoppingBag className="h-4 w-4" />
                أضف إلى السلة
              </button>
              <button
                type="button"
                onClick={() => {
                  setWish((v) => !v);
                  toast.success(wish ? "تمت الإزالة من قائمة الأمنيات" : "تمت الإضافة إلى قائمة الأمنيات");
                }}
                aria-label="أضف إلى قائمة الأمنيات"
                className="rounded-full border border-border px-4 transition hover:border-primary"
              >
                <Heart className={`h-5 w-5 ${wish ? "fill-destructive text-destructive" : ""}`} />
              </button>
            </div>
          </div>

          <div className="mt-6 flex items-center gap-2 text-xs text-muted-foreground">
            <Truck className="h-4 w-4 text-primary" />
            الدفع عند الاستلام — التوصيل خلال ٢-٤ أيام عمل
          </div>

          <div className="mt-8 grid gap-3 sm:grid-cols-3">
            {notes.map((n) => (
              <div key={n.label} className="rounded-2xl border border-border bg-card p-4">
                <p className="text-xs font-bold text-primary">{n.label}</p>
                <p className="mt-1.5 text-xs leading-6 text-muted-foreground">{n.value ?? "-"}</p>
              </div>
            ))}
          </div>

          <ul className="mt-8 space-y-2 text-xs text-muted-foreground">
            {["منتج أصلي ١٠٠٪ من ABQ", "ثبات طويل يصل إلى ١٢ ساعة", "إرجاع خلال ٧ أيام"].map(
              (t) => (
                <li key={t} className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-primary" />
                  {t}
                </li>
              ),
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}
