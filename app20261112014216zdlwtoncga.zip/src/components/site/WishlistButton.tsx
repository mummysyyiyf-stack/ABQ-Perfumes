"use client";

import { useEffect, useState } from "react";
import { Heart } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/components/AuthProvider";
import { cn } from "@/lib/format";

export default function WishlistButton({
  productId,
  className,
}: {
  productId: string;
  className?: string;
}) {
  const { user } = useAuth();
  const [active, setActive] = useState(false);
  const [loading, setLoading] = useState(false);

  const key = user ? `abq_wishlist_${user.id}` : "abq_wishlist_guest";

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(key);
      const list: string[] = raw ? JSON.parse(raw) : [];
      setActive(list.includes(productId));
    } catch {
      // ignore
    }
  }, [key, productId]);

  const toggle = async () => {
    setLoading(true);
    try {
      const raw = window.localStorage.getItem(key);
      const list: string[] = raw ? JSON.parse(raw) : [];
      const next = list.includes(productId)
        ? list.filter((id) => id !== productId)
        : [...list, productId];
      window.localStorage.setItem(key, JSON.stringify(next));

      if (user) {
        if (list.includes(productId)) {
          await supabase
            .from("wishlist_items")
            .delete()
            .eq("product_id", productId)
            .eq("user_id", user.id);
        } else {
          await supabase
            .from("wishlist_items")
            .insert({ product_id: productId, user_id: user.id });
        }
      }

      setActive(next.includes(productId));
      toast.success(
        next.includes(productId)
          ? "تمت الإضافة إلى قائمة الأمنيات"
          : "تمت الإزالة من قائمة الأمنيات",
      );
    } catch {
      toast.error("تعذر تحديث قائمة الأمنيات");
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      type="button"
      onClick={toggle}
      disabled={loading}
      aria-pressed={active}
      aria-label="أضف إلى قائمة الأمنيات"
      className={cn(
        "rounded-full border border-border bg-background/85 p-2 backdrop-blur transition hover:border-primary",
        className,
      )}
    >
      <Heart className={cn("h-4 w-4", active && "fill-destructive text-destructive")} />
    </button>
  );
}
