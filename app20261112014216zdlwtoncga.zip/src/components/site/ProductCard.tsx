"use client";

import Link from "next/link";
import { useState } from "react";
import { Heart, Plus, Star } from "lucide-react";
import { toast } from "sonner";
import { useCart } from "@/components/CartProvider";
import { formatEGP } from "@/lib/format";
import type { Product, ProductVariant } from "@/lib/types";

export default function ProductCard({
  product,
  variants,
}: {
  product: Product;
  variants: ProductVariant[];
}) {
  const { addLine } = useCart();
  const [size, setSize] = useState(variants[0]?.id ?? "");
  const [wishlisted, setWishlisted] = useState(false);

  const selected = variants.find((v) => v.id === size);
  const base = selected?.price_egp ?? 0;
  const discounted = product.discount_percent
    ? Math.round(base * (1 - product.discount_percent / 100))
    : base;

  const handleAdd = () => {
    if (!selected) return;
    if (selected.stock <= 0) {
      toast.error("هذا الحجم غير متوفر حاليًا");
      return;
    }
    addLine({
      productId: product.id,
      variantId: selected.id,
      name: product.name,
      sizeLabel: selected.size_label,
      price: discounted,
      imageUrl: product.image_url,
      stock: selected.stock,
    });
    toast.success(`تمت إضافة ${product.name} (${selected.size_label}) إلى السلة`);
  };

  const toggleWish = () => {
    setWishlisted((v) => !v);
    toast.success(wishlisted ? "تمت الإزالة من قائمة الأمنيات" : "تمت الإضافة إلى قائمة الأمنيات");
  };

  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition hover:border-primary/60 hover:shadow-xl hover:shadow-black/5">
      <Link href={`/products/${product.slug}`} className="relative block aspect-[4/5] overflow-hidden bg-muted">
        {product.image_url && (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={product.image_url}
            alt={`عطر ${product.name} من ABQ`}
            className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
          />
        )}
        <div className="absolute right-3 top-3 flex flex-col gap-2">
          {product.is_offer && product.discount_percent > 0 && (
            <span className="rounded-full bg-primary px-3 py-1 text-xs font-bold text-primary-foreground">
              خصم {product.discount_percent}%
            </span>
          )}
          {product.is_best_seller && (
            <span className="rounded-full bg-secondary px-3 py-1 text-xs font-bold text-primary">
              الأكثر مبيعًا
            </span>
          )}
        </div>
        <button
          type="button"
          onClick={toggleWish}
          aria-label="أضف إلى قائمة الأمنيات"
          className="absolute left-3 top-3 rounded-full bg-background/85 p-2 backdrop-blur transition hover:bg-background"
        >
          <Heart
            className={`h-4 w-4 ${wishlisted ? "fill-destructive text-destructive" : ""}`}
          />
        </button>
      </Link>

      <div className="flex flex-1 flex-col gap-3 p-4">
        <div>
          <p className="text-xs uppercase tracking-widest text-muted-foreground">ABQ</p>
          <Link href={`/products/${product.slug}`} className="mt-1 block font-bold leading-6 hover:text-primary">
            {product.name}
          </Link>
          <p className="mt-1 line-clamp-2 text-xs leading-5 text-muted-foreground">
            {product.description}
          </p>
        </div>

        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Star className="h-3.5 w-3.5 fill-primary text-primary" />
          <span className="font-semibold text-foreground">{product.rating ?? 0}</span>
          <span>({product.review_count ?? 0} تقييم)</span>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {variants.map((v) => (
            <button
              key={v.id}
              type="button"
              onClick={() => setSize(v.id)}
              disabled={v.stock <= 0}
              className={`rounded-full border px-3 py-1 text-xs font-semibold transition ${
                size === v.id
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border hover:border-primary/60"
              } ${v.stock <= 0 ? "opacity-40 line-through" : ""}`}
            >
              {v.size_label} · {formatEGP(v.price_egp)}
            </button>
          ))}
        </div>

        <div className="mt-auto flex items-center justify-between gap-2 border-t border-border pt-3">
          <div>
            {product.discount_percent > 0 && selected && (
              <span className="text-xs text-muted-foreground line-through">
                {formatEGP(selected.price_egp)}
              </span>
            )}
            <p className="text-lg font-bold text-primary">{formatEGP(discounted)}</p>
          </div>
          <button
            type="button"
            onClick={handleAdd}
            className="inline-flex items-center gap-1.5 rounded-full bg-secondary px-4 py-2 text-xs font-bold text-secondary-foreground transition hover:bg-primary hover:text-primary-foreground"
          >
            <Plus className="h-4 w-4" />
            أضف للسلة
          </button>
        </div>
      </div>
    </article>
  );
}
