"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/components/AuthProvider";

export default function AuthForms() {
  const { user, signOut } = useAuth();
  const params = useSearchParams();
  const [mode, setMode] = useState<"login" | "signup">(
    params.get("mode") === "signup" ? "signup" : "login",
  );
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const m = params.get("mode");
    if (m === "signup" || m === "login") setMode(m);
  }, [params]);

  const handleEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (mode === "signup") {
        const res = await fetch("/api/auth/signup", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password, full_name: fullName }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "تعذر إنشاء الحساب");
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("تم إنشاء حسابك بنجاح");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success("تم تسجيل الدخول بنجاح");
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "تعذر إتمام العملية");
    } finally {
      setBusy(false);
    }
  };

  const handleGoogle = async () => {
    try {
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: {
          redirectTo: `${window.location.origin}/account`,
          skipBrowserRedirect: true,
        },
      });
      if (error) throw error;
      if (!data?.url) return;

      const popup = window.open(data.url, "google-login", "width=500,height=600");
      const {
        data: { subscription },
      } = supabase.auth.onAuthStateChange((event, session) => {
        if (event === "SIGNED_IN" && session) {
          popup?.close();
          subscription.unsubscribe();
          toast.success("تم تسجيل الدخول عبر Google");
        }
      });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "تعذر تسجيل الدخول عبر Google");
    }
  };

  if (user) {
    return (
      <div className="rounded-2xl border border-border bg-card p-8 text-center">
        <p className="font-[family-name:var(--font-playfair)] text-2xl font-bold tracking-[0.35em] gold-text">
          ABQ
        </p>
        <h1 className="mt-4 text-2xl font-extrabold">حسابك</h1>
        <p className="mt-2 text-sm text-muted-foreground">{user.email}</p>
        <button
          onClick={async () => {
            await signOut();
            toast.success("تم تسجيل الخروج");
          }}
          className="mt-6 rounded-full border border-border px-6 py-2.5 text-sm font-bold transition hover:border-primary"
        >
          تسجيل الخروج
        </button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-md px-4 py-12">
      <div className="rounded-2xl border border-border bg-card p-8">
        <p className="text-center font-[family-name:var(--font-playfair)] text-3xl font-bold tracking-[0.35em] gold-text">
          ABQ
        </p>
        <h1 className="mt-4 text-center text-2xl font-extrabold">
          {mode === "login" ? "تسجيل الدخول" : "إنشاء حساب جديد"}
        </h1>
        <p className="mt-1 text-center text-xs text-muted-foreground">
          {mode === "login"
            ? "ادخل إلى حسابك لمتابعة طلباتك"
            : "أنشئ حسابك لحفظ عناوينك ومتابعة طلباتك"}
        </p>

        <form onSubmit={handleEmail} className="mt-7 space-y-4">
          {mode === "signup" && (
            <div>
              <label htmlFor="full_name" className="mb-1.5 block text-sm font-semibold">
                الاسم الكامل
              </label>
              <input
                id="full_name"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none focus:border-primary"
                placeholder="اسمك الكامل"
              />
            </div>
          )}

          <div>
            <label htmlFor="email" className="mb-1.5 block text-sm font-semibold">
              البريد الإلكتروني
            </label>
            <input
              id="email"
              type="email"
              dir="ltr"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full rounded-xl border border-input bg-background px-4 py-3 text-right text-sm outline-none focus:border-primary"
              placeholder="you@example.com"
            />
          </div>

          <div>
            <label htmlFor="password" className="mb-1.5 block text-sm font-semibold">
              كلمة المرور
            </label>
            <input
              id="password"
              type="password"
              dir="ltr"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={6}
              className="w-full rounded-xl border border-input bg-background px-4 py-3 text-right text-sm outline-none focus:border-primary"
              placeholder="••••••••"
            />
          </div>

          <button
            type="submit"
            disabled={busy}
            className="flex w-full items-center justify-center gap-2 rounded-full bg-secondary px-6 py-3 text-sm font-bold text-secondary-foreground transition hover:bg-primary hover:text-primary-foreground disabled:opacity-60"
          >
            {busy && <Loader2 className="h-4 w-4 animate-spin" />}
            {mode === "login" ? "تسجيل الدخول" : "إنشاء الحساب"}
          </button>
        </form>

        <div className="my-6 flex items-center gap-3 text-xs text-muted-foreground">
          <span className="h-px flex-1 bg-border" />
          أو
          <span className="h-px flex-1 bg-border" />
        </div>

        <button
          onClick={handleGoogle}
          className="flex w-full items-center justify-center gap-2 rounded-full border border-border px-6 py-3 text-sm font-bold transition hover:border-primary"
        >
          <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
            <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3l5.7-5.7C34.1 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.2-.1-2.3-.4-3.5z" />
            <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.9 1.2 8 3l5.7-5.7C34.1 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" />
            <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.3 35.1 26.7 36 24 36c-5.3 0-9.7-3.3-11.3-8l-6.5 5C9.6 39.6 16.2 44 24 44z" />
            <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.3 4.2-4.1 5.6l6.2 5.2C40.8 36.2 44 30.8 44 24c0-1.2-.1-2.3-.4-3.5z" />
          </svg>
          المتابعة باستخدام Google
        </button>

        <button
          onClick={() => setMode(mode === "login" ? "signup" : "login")}
          className="mt-6 w-full text-center text-xs font-semibold text-muted-foreground hover:text-primary"
        >
          {mode === "login"
            ? "ليس لديك حساب؟ أنشئ حسابًا جديدًا"
            : "لديك حساب بالفعل؟ سجّل الدخول"}
        </button>
      </div>
    </div>
  );
}
