"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, Search, ShoppingBag, User, X, Heart, LayoutDashboard } from "lucide-react";
import { useCart } from "@/components/CartProvider";
import { useAuth } from "@/components/AuthProvider";
import { cn } from "@/lib/format";

const NAV = [
  { href: "/", label: "الرئيسية" },
  { href: "/products", label: "كل العطور" },
  { href: "/products?category=men", label: "رجالية" },
  { href: "/products?category=women", label: "نسائية" },
  { href: "/products?category=unisex", label: "مشتركة" },
  { href: "/products?category=luxury", label: "فاخرة" },
  { href: "/products?category=offers", label: "العروض" },
];

export default function SiteHeader() {
  const { count } = useCart();
  const { user, isAdmin } = useAuth();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur">
      <div className="luxury-gradient">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-2 text-xs text-primary">
          <span>شحن مجاني للطلبات فوق ١٠٠٠ ج.م — الدفع عند الاستلام في جميع محافظات مصر</span>
          <span className="hidden md:inline">ABQ · عطور فاخرة</span>
        </div>
      </div>

      <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-4">
        <button
          className="md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="القائمة"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>

        <Link href="/" className="shrink-0">
          <span className="font-[family-name:var(--font-playfair)] text-3xl font-bold tracking-[0.35em] gold-text">
            ABQ
          </span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {NAV.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              className="rounded-full px-3 py-2 text-sm font-medium text-foreground/80 transition hover:bg-muted hover:text-foreground"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <form
          className="mr-auto hidden max-w-xs flex-1 items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5 lg:flex"
          onSubmit={(e) => {
            e.preventDefault();
            window.location.href = `/products?q=${encodeURIComponent(query)}`;
          }}
        >
          <Search className="h-4 w-4 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث عن عطر..."
            className="w-full bg-transparent text-sm outline-none"
            aria-label="بحث"
          />
        </form>

        <div className="mr-auto flex items-center gap-1 lg:mr-0">
          <form
            className="flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5 lg:hidden"
            onSubmit={(e) => {
              e.preventDefault();
              window.location.href = `/products?q=${encodeURIComponent(query)}`;
            }}
          >
            <Search className="h-4 w-4 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="بحث"
              className="w-16 bg-transparent text-sm outline-none"
              aria-label="بحث"
            />
          </form>

          <Link
            href="/wishlist"
            className="rounded-full p-2 transition hover:bg-muted"
            aria-label="قائمة الأمنيات"
          >
            <Heart className="h-5 w-5" />
          </Link>

          {isAdmin && (
            <Link
              href="/admin"
              className="rounded-full p-2 transition hover:bg-muted"
              aria-label="لوحة الإدارة"
            >
              <LayoutDashboard className="h-5 w-5 text-primary" />
            </Link>
          )}

          <Link
            href={user ? "/account" : "/account?mode=login"}
            className="rounded-full p-2 transition hover:bg-muted"
            aria-label="الحساب"
          >
            <User className="h-5 w-5" />
          </Link>

          <Link
            href="/cart"
            className="relative rounded-full p-2 transition hover:bg-muted"
            aria-label="السلة"
          >
            <ShoppingBag className="h-5 w-5" />
            {count > 0 && (
              <span className="absolute -top-0.5 -left-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-[11px] font-bold text-primary-foreground">
                {count}
              </span>
            )}
          </Link>
        </div>
      </div>

      <div className={cn("border-t border-border md:hidden", open ? "block" : "hidden")}>
        <nav className="mx-auto flex max-w-7xl flex-col px-4 py-2">
          {NAV.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              onClick={() => setOpen(false)}
              className="border-b border-border/60 py-3 text-sm font-medium last:border-0"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
