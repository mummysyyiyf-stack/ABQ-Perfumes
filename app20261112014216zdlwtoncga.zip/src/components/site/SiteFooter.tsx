import Link from "next/link";
import { Instagram, Facebook, MessageCircle, Mail } from "lucide-react";

export default function SiteFooter() {
  return (
    <footer className="mt-16 bg-secondary text-secondary-foreground">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <p className="font-[family-name:var(--font-playfair)] text-3xl font-bold tracking-[0.35em] gold-text">
            ABQ
          </p>
          <p className="mt-3 text-sm leading-6 text-secondary-foreground/70">
            عطور فاخرة مختارة بعناية من ABQ. نفحات عصرية تدوم، وبأسعار تناسب الجميع.
          </p>
        </div>

        <div>
          <h3 className="mb-3 text-sm font-bold text-primary">تسوق</h3>
          <ul className="space-y-2 text-sm text-secondary-foreground/70">
            <li>
              <Link href="/products" className="transition hover:text-primary">
                كل العطور
              </Link>
            </li>
            <li>
              <Link href="/products?category=men" className="transition hover:text-primary">
                عطور رجالية
              </Link>
            </li>
            <li>
              <Link href="/products?category=women" className="transition hover:text-primary">
                عطور نسائية
              </Link>
            </li>
            <li>
              <Link href="/products?category=offers" className="transition hover:text-primary">
                العروض
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="mb-3 text-sm font-bold text-primary">خدمة العملاء</h3>
          <ul className="space-y-2 text-sm text-secondary-foreground/70">
            <li>
              <Link href="/cart" className="transition hover:text-primary">
                سلة المشتريات
              </Link>
            </li>
            <li>
              <Link href="/account" className="transition hover:text-primary">
                حسابي
              </Link>
            </li>
            <li>
              <Link href="/account?mode=login" className="transition hover:text-primary">
                تسجيل الدخول
              </Link>
            </li>
            <li>
              <Link href="/wishlist" className="transition hover:text-primary">
                قائمة الأمنيات
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h3 className="mb-3 text-sm font-bold text-primary">تواصل معنا</h3>
          <ul className="space-y-3 text-sm text-secondary-foreground/70">
            <li className="flex items-center gap-2">
              <MessageCircle className="h-4 w-4 text-primary" />
              واتساب: 0100 000 0000
            </li>
            <li className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-primary" />
              care@abq.com
            </li>
            <li className="flex items-center gap-2">
              <Instagram className="h-4 w-4 text-primary" />
              <span dir="ltr">@abq.perfumes</span>
            </li>
            <li className="flex items-center gap-2">
              <Facebook className="h-4 w-4 text-primary" />
              <span dir="ltr">ABQ Perfumes</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-secondary-foreground/10 py-4 text-center text-xs text-secondary-foreground/60">
        © {new Date().getFullYear()} ABQ — جميع الحقوق محفوظة. الدفع عند الاستلام متاح في جميع محافظات مصر.
      </div>
    </footer>
  );
}
