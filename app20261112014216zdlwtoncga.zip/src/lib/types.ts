export type Product = {
  id: string;
  name: string;
  slug: string;
  brand: string;
  description: string | null;
  category_id: string | null;
  gender: string;
  top_notes: string | null;
  heart_notes: string | null;
  base_notes: string | null;
  longevity: string | null;
  image_url: string | null;
  rating: number | null;
  review_count: number | null;
  is_featured: boolean;
  is_best_seller: boolean;
  is_offer: boolean;
  discount_percent: number;
  is_active: boolean;
};

export type ProductVariant = {
  id: string;
  product_id: string;
  size_label: string;
  volume_ml: number;
  price_egp: number;
  stock: number;
  is_active: boolean;
};

export type Category = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  sort_order: number;
};

export type Order = {
  id: string;
  order_number: string;
  user_id: string | null;
  customer_name: string;
  phone: string;
  address: string;
  city: string;
  notes: string | null;
  subtotal: number;
  discount: number;
  delivery_fee: number;
  total: number;
  payment_method: string;
  status: OrderStatus;
  created_at: string;
};

export type OrderStatus = "new" | "confirmed" | "shipped" | "delivered" | "cancelled";

export type OrderItem = {
  id: string;
  order_id: string;
  product_id: string | null;
  variant_id: string | null;
  product_name: string;
  variant_label: string;
  unit_price: number;
  quantity: number;
  line_total: number;
  image_url: string | null;
};

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  new: "طلب جديد",
  confirmed: "تم التأكيد",
  shipped: "تم الشحن",
  delivered: "تم التسليم",
  cancelled: "ملغي",
};

export const CATEGORY_LABELS: Record<string, string> = {
  men: "عطور رجالية",
  women: "عطور نسائية",
  unisex: "عطور مشتركة",
  luxury: "عطور فاخرة",
  offers: "العروض",
};
