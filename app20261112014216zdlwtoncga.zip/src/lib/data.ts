import { supabaseAdmin } from "@/integrations/supabase/server";
import type { Category, Product, ProductVariant } from "./types";

export async function getCategories(): Promise<Category[]> {
  const { data } = await supabaseAdmin
    .from("product_categories")
    .select("id,name,slug,description,sort_order")
    .eq("is_active", true)
    .order("sort_order", { ascending: true });
  return (data as Category[]) ?? [];
}

export async function getProducts(options?: {
  categorySlug?: string;
  search?: string;
  limit?: number;
}): Promise<Product[]> {
  let query = supabaseAdmin
    .from("products")
    .select(
      "id,name,slug,brand,description,category_id,gender,top_notes,heart_notes,base_notes,longevity,image_url,rating,review_count,is_featured,is_best_seller,is_offer,discount_percent,is_active",
    )
    .eq("is_active", true)
    .order("created_at", { ascending: false })
    .limit(options?.limit ?? 100);

  if (options?.categorySlug && options.categorySlug !== "all") {
    const { data: cat } = await supabaseAdmin
      .from("product_categories")
      .select("id")
      .eq("slug", options.categorySlug)
      .maybeSingle();
    if (cat) query = query.eq("category_id", cat.id);
  }

  if (options?.search) {
    query = query.ilike("name", `%${options.search}%`);
  }

  const { data } = await query;
  return (data as Product[]) ?? [];
}

export async function getProductBySlug(slug: string) {
  const { data } = await supabaseAdmin
    .from("products")
    .select(
      "id,name,slug,brand,description,category_id,gender,top_notes,heart_notes,base_notes,longevity,image_url,rating,review_count,is_featured,is_best_seller,is_offer,discount_percent,is_active",
    )
    .eq("slug", slug)
    .maybeSingle();
  return data as Product | null;
}

export async function getVariants(productIds: string[]): Promise<ProductVariant[]> {
  if (productIds.length === 0) return [];
  const { data } = await supabaseAdmin
    .from("product_variants")
    .select("id,product_id,size_label,volume_ml,price_egp,stock,is_active")
    .in("product_id", productIds)
    .eq("is_active", true)
    .order("volume_ml", { ascending: true });
  return (data as ProductVariant[]) ?? [];
}

export async function getAllProductsForAdmin(): Promise<Product[]> {
  const { data } = await supabaseAdmin
    .from("products")
    .select(
      "id,name,slug,brand,description,category_id,gender,top_notes,heart_notes,base_notes,longevity,image_url,rating,review_count,is_featured,is_best_seller,is_offer,discount_percent,is_active",
    )
    .order("created_at", { ascending: false });
  return (data as Product[]) ?? [];
}

export async function getAllVariants(): Promise<ProductVariant[]> {
  const { data } = await supabaseAdmin
    .from("product_variants")
    .select("id,product_id,size_label,volume_ml,price_egp,stock,is_active")
    .order("volume_ml", { ascending: true });
  return (data as ProductVariant[]) ?? [];
}
