export function formatEGP(value: number | string | null | undefined) {
  const n = Number(value ?? 0);
  return `${n.toLocaleString("ar-EG", { maximumFractionDigits: 2 })} ج.م`;
}

export function formatDate(value: string | null | undefined) {
  if (!value) return "-";
  try {
    return new Date(value).toLocaleDateString("ar-EG", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  } catch {
    return "-";
  }
}

export function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}
