import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/integrations/supabase/server";

export const dynamic = "force-dynamic";

async function requireAdmin(request: Request) {
  const authHeader = request.headers.get("Authorization");
  const token = authHeader?.replace("Bearer ", "");
  if (!token) return null;
  const { data: userData, error } = await supabaseAdmin.auth.getUser(token);
  if (error || !userData?.user) return null;
  const { data: role } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userData.user.id)
    .eq("role", "admin")
    .maybeSingle();
  return role ? userData.user : null;
}

export async function GET(request: Request) {
  if (!(await requireAdmin(request)))
    return NextResponse.json({ error: "غير مصرح" }, { status: 403 });

  const { data: orders } = await supabaseAdmin
    .from("orders")
    .select("id,status,total,created_at")
    .limit(1000);

  const list = orders ?? [];
  const valid = list.filter((o) => o.status !== "cancelled");
  const revenue = valid.reduce((s, o) => s + Number(o.total ?? 0), 0);
  const avg = valid.length ? revenue / valid.length : 0;

  const byStatus: Record<string, number> = {
    new: 0,
    confirmed: 0,
    shipped: 0,
    delivered: 0,
    cancelled: 0,
  };
  for (const o of list) {
    byStatus[o.status] = (byStatus[o.status] ?? 0) + 1;
  }

  const days: Array<{ date: string; total: number }> = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    days.push({ date: key, total: 0 });
  }
  const dayMap = new Map(days.map((d) => [d.date, d]));
  for (const o of valid) {
    const key = String(o.created_at).slice(0, 10);
    const entry = dayMap.get(key);
    if (entry) entry.total += Number(o.total ?? 0);
  }

  const { data: items } = await supabaseAdmin
    .from("order_items")
    .select("product_name,quantity,line_total")
    .limit(5000);

  const soldMap = new Map<string, { qty: number; revenue: number }>();
  for (const it of items ?? []) {
    const key = it.product_name;
    const cur = soldMap.get(key) ?? { qty: 0, revenue: 0 };
    cur.qty += Number(it.quantity ?? 0);
    cur.revenue += Number(it.line_total ?? 0);
    soldMap.set(key, cur);
  }
  const topProducts = Array.from(soldMap.entries())
    .map(([name, v]) => ({ name, qty: v.qty, revenue: v.revenue }))
    .sort((a, b) => b.qty - a.qty)
    .slice(0, 5);

  const { data: variants } = await supabaseAdmin
    .from("product_variants")
    .select("id,product_id,size_label,stock")
    .limit(500);

  const { data: products } = await supabaseAdmin
    .from("products")
    .select("id,name")
    .limit(200);
  const nameMap = new Map((products ?? []).map((p) => [p.id, p.name]));

  const lowStock = (variants ?? [])
    .filter((v) => Number(v.stock) <= 5)
    .map((v) => ({
      id: v.id,
      name: nameMap.get(v.product_id) ?? "—",
      size: v.size_label,
      stock: Number(v.stock),
    }))
    .slice(0, 10);

  return NextResponse.json({
    revenue,
    orderCount: list.length,
    validOrderCount: valid.length,
    averageOrder: avg,
    byStatus,
    daily: days,
    topProducts,
    lowStock,
  });
}
