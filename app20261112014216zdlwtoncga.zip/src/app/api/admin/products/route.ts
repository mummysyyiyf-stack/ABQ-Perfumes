import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/integrations/supabase/server";

export const dynamic = "force-dynamic";

async function requireAdmin(request: Request) {
  const authHeader = request.headers.get("Authorization");
  const token = authHeader?.replace("Bearer ", "");
  if (!token) return null;
  const { data: userData, error } = await supabaseAdmin.auth.getUser(token);
  if (error || !userData?.user) return null;
  const { data: role } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userData.user.id)
    .eq("role", "admin")
    .maybeSingle();
  return role ? userData.user : null;
}

export async function GET(request: Request) {
  if (!(await requireAdmin(request)))
    return NextResponse.json({ error: "غير مصرح" }, { status: 403 });

  const { data: products } = await supabaseAdmin
    .from("products")
    .select(
      "id,name,slug,brand,description,category_id,gender,top_notes,heart_notes,base_notes,longevity,image_url,rating,review_count,is_featured,is_best_seller,is_offer,discount_percent,is_active",
    )
    .order("created_at", { ascending: false });

  const { data: variants } = await supabaseAdmin
    .from("product_variants")
    .select("id,product_id,size_label,volume_ml,price_egp,stock,is_active")
    .order("volume_ml", { ascending: true });

  const { data: categories } = await supabaseAdmin
    .from("product_categories")
    .select("id,name,slug,sort_order")
    .order("sort_order", { ascending: true });

  return NextResponse.json({
    products: products ?? [],
    variants: variants ?? [],
    categories: categories ?? [],
  });
}

export async function POST(request: Request) {
  if (!(await requireAdmin(request)))
    return NextResponse.json({ error: "غير مصرح" }, { status: 403 });

  const body = await request.json();
  const {
    id,
    name,
    slug,
    description,
    category_id,
    gender,
    top_notes,
    heart_notes,
    base_notes,
    longevity,
    image_url,
    is_featured,
    is_best_seller,
    is_offer,
    discount_percent,
    is_active,
    variants,
  } = body;

  if (!name || !slug) {
    return NextResponse.json({ error: "الاسم والرابط المختصر مطلوبان" }, { status: 400 });
  }

  const payload = {
    name,
    slug,
    brand: "ABQ",
    description: description ?? null,
    category_id: category_id ?? null,
    gender: gender ?? "unisex",
    top_notes: top_notes ?? null,
    heart_notes: heart_notes ?? null,
    base_notes: base_notes ?? null,
    longevity: longevity ?? null,
    image_url: image_url ?? null,
    is_featured: !!is_featured,
    is_best_seller: !!is_best_seller,
    is_offer: !!is_offer,
    discount_percent: Number(discount_percent ?? 0),
    is_active: is_active ?? true,
  };

  let productId = id;

  if (id) {
    const { error } = await supabaseAdmin.from("products").update(payload).eq("id", id);
    if (error) return NextResponse.json({ error: "تعذر حفظ المنتج" }, { status: 500 });
  } else {
    const { data, error } = await supabaseAdmin
      .from("products")
      .insert(payload)
      .select("id")
      .maybeSingle();
    if (error || !data)
      return NextResponse.json({ error: "تعذر إضافة المنتج" }, { status: 500 });
    productId = data.id;
  }

  if (Array.isArray(variants)) {
    for (const v of variants) {
      if (v.id) {
        await supabaseAdmin
          .from("product_variants")
          .update({
            size_label: v.size_label,
            volume_ml: Number(v.volume_ml),
            price_egp: Number(v.price_egp),
            stock: Number(v.stock),
            is_active: v.is_active ?? true,
          })
          .eq("id", v.id);
      } else {
        await supabaseAdmin.from("product_variants").insert({
          product_id: productId,
          size_label: v.size_label,
          volume_ml: Number(v.volume_ml),
          price_egp: Number(v.price_egp),
          stock: Number(v.stock),
          is_active: v.is_active ?? true,
        });
      }
    }
  }

  return NextResponse.json({ id: productId });
}

export async function DELETE(request: Request) {
  if (!(await requireAdmin(request)))
    return NextResponse.json({ error: "غير مصرح" }, { status: 403 });

  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "معرّف المنتج مطلوب" }, { status: 400 });

  await supabaseAdmin.from("product_variants").delete().eq("product_id", id);
  await supabaseAdmin.from("wishlist_items").delete().eq("product_id", id);
  const { error } = await supabaseAdmin.from("products").delete().eq("id", id);
  if (error) return NextResponse.json({ error: "تعذر حذف المنتج" }, { status: 500 });

  return NextResponse.json({ ok: true });
}
