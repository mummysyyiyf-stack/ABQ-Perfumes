import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/integrations/supabase/server";

export const dynamic = "force-dynamic";

async function requireAdmin(request: Request) {
  const authHeader = request.headers.get("Authorization");
  const token = authHeader?.replace("Bearer ", "");
  if (!token) return null;
  const { data: userData, error } = await supabaseAdmin.auth.getUser(token);
  if (error || !userData?.user) return null;
  const { data: role } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userData.user.id)
    .eq("role", "admin")
    .maybeSingle();
  return role ? userData.user : null;
}

export async function GET(request: Request) {
  if (!(await requireAdmin(request)))
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status");
  let query = supabaseAdmin
    .from("orders")
    .select(
      "id,order_number,customer_name,phone,address,city,notes,subtotal,discount,delivery_fee,total,payment_method,status,created_at",
    )
    .order("created_at", { ascending: false })
    .limit(200);
  if (status && status !== "all") query = query.eq("status", status);

  const { data: orders, error: ordersError } = await query;
  if (ordersError)
    return NextResponse.json({ error: "تعذر تحميل الطلبات" }, { status: 500 });

  const orderIds = (orders ?? []).map((o) => o.id);
  let items: unknown[] = [];
  if (orderIds.length > 0) {
    const { data } = await supabaseAdmin
      .from("order_items")
      .select(
        "id,order_id,product_name,variant_label,unit_price,quantity,line_total,image_url",
      )
      .in("order_id", orderIds);
    items = data ?? [];
  }

  return NextResponse.json({ orders: orders ?? [], items });
}

export async function PATCH(request: Request) {
  if (!(await requireAdmin(request)))
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });

  const body = await request.json();
  const { orderId, status, note } = body as {
    orderId: string;
    status: string;
    note?: string;
  };

  const allowed = ["new", "confirmed", "shipped", "delivered", "cancelled"];
  if (!orderId || !allowed.includes(status)) {
    return NextResponse.json({ error: "بيانات غير صالحة" }, { status: 400 });
  }

  const { error } = await supabaseAdmin
    .from("orders")
    .update({ status })
    .eq("id", orderId);
  if (error) return NextResponse.json({ error: "تعذر تحديث الطلب" }, { status: 500 });

  await supabaseAdmin.from("order_status_history").insert({
    order_id: orderId,
    status,
    note: note || null,
  });

  return NextResponse.json({ ok: true });
}
