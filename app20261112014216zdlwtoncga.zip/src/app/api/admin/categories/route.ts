import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/integrations/supabase/server";

export const dynamic = "force-dynamic";

async function requireAdmin(request: Request) {
  const authHeader = request.headers.get("Authorization");
  const token = authHeader?.replace("Bearer ", "");
  if (!token) return null;
  const { data: userData, error } = await supabaseAdmin.auth.getUser(token);
  if (error || !userData?.user) return null;
  const { data: role } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userData.user.id)
    .eq("role", "admin")
    .maybeSingle();
  return role ? userData.user : null;
}

export async function POST(request: Request) {
  if (!(await requireAdmin(request)))
    return NextResponse.json({ error: "غير مصرح" }, { status: 403 });

  const body = await request.json();
  const name = String(body.name ?? "").trim();
  const slug = String(body.slug ?? "").trim();
  if (!name) return NextResponse.json({ error: "اسم الفئة مطلوب" }, { status: 400 });

  const { data, error } = await supabaseAdmin
    .from("product_categories")
    .insert({
      name,
      slug: slug || name.toLowerCase().replace(/\s+/g, "-"),
      description: body.description ?? null,
      sort_order: Number(body.sort_order ?? 0),
      is_active: true,
    })
    .select("id")
    .maybeSingle();

  if (error) return NextResponse.json({ error: "تعذر إضافة الفئة" }, { status: 500 });
  return NextResponse.json({ id: data?.id });
}

export async function DELETE(request: Request) {
  if (!(await requireAdmin(request)))
    return NextResponse.json({ error: "غير مصرح" }, { status: 403 });

  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "معرّف الفئة مطلوب" }, { status: 400 });

  const { error } = await supabaseAdmin.from("product_categories").delete().eq("id", id);
  if (error) return NextResponse.json({ error: "تعذر حذف الفئة" }, { status: 500 });
  return NextResponse.json({ ok: true });
}
