import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/integrations/supabase/server";

export const dynamic = "force-dynamic";

type Payload = {
  customer_name: string;
  phone: string;
  address: string;
  city: string;
  notes?: string;
  lines: Array<{ variant_id: string; quantity: number }>;
  user_id?: string | null;
};

function makeOrderNumber() {
  const now = new Date();
  const stamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}`;
  const rand = Math.floor(Math.random() * 9000 + 1000);
  return `ABQ-${stamp}-${rand}`;
}

export async function POST(request: Request) {
  let body: Payload;
  try {
    body = (await request.json()) as Payload;
  } catch {
    return NextResponse.json({ error: "بيانات غير صالحة" }, { status: 400 });
  }

  const { customer_name, phone, address, city, notes, lines, user_id } = body;

  if (!customer_name?.trim() || !phone?.trim() || !address?.trim() || !city?.trim()) {
    return NextResponse.json(
      { error: "يرجى تعبئة الاسم ورقم الهاتف والعنوان والمدينة" },
      { status: 400 },
    );
  }
  if (!/^01[0-25]\d{8}$/.test(phone.replace(/\s/g, ""))) {
    return NextResponse.json(
      { error: "رقم الهاتف غير صحيح، مثال: 01012345678" },
      { status: 400 },
    );
  }
  if (!lines?.length) {
    return NextResponse.json({ error: "السلة فارغة" }, { status: 400 });
  }

  const variantIds = lines.map((l) => l.variant_id);
  const { data: variants, error: variantError } = await supabaseAdmin
    .from("product_variants")
    .select("id,product_id,size_label,price_egp,stock,is_active")
    .in("id", variantIds);
  if (variantError || !variants || variants.length !== variantIds.length) {
    return NextResponse.json({ error: "تعذر التحقق من المنتجات" }, { status: 400 });
  }

  const productIds = Array.from(new Set(variants.map((v) => v.product_id)));
  const { data: products } = await supabaseAdmin
    .from("products")
    .select("id,name,image_url,discount_percent")
    .in("id", productIds);
  const productMap = new Map((products ?? []).map((p) => [p.id, p]));

  const items = [];
  let subtotal = 0;

  for (const line of lines) {
    const variant = variants.find((v) => v.id === line.variant_id);
    if (!variant || !variant.is_active) {
      return NextResponse.json({ error: "أحد الأحجام لم يعد متاحًا" }, { status: 400 });
    }
    const qty = Math.max(1, Math.floor(line.quantity));
    if (variant.stock < qty) {
      return NextResponse.json(
        { error: `الكمية المطلوبة من ${variant.size_label} أكبر من المتاح` },
        { status: 400 },
      );
    }
    const product = productMap.get(variant.product_id);
    const discount = Number(product?.discount_percent ?? 0);
    const unitPrice = discount
      ? Math.round(Number(variant.price_egp) * (1 - discount / 100))
      : Number(variant.price_egp);
    const lineTotal = unitPrice * qty;
    subtotal += lineTotal;

    items.push({
      product_id: variant.product_id,
      variant_id: variant.id,
      product_name: product?.name ?? "عطر ABQ",
      variant_label: variant.size_label,
      unit_price: unitPrice,
      quantity: qty,
      line_total: lineTotal,
      image_url: product?.image_url ?? null,
    });
  }

  const deliveryFee = subtotal >= 1000 ? 0 : 50;
  const total = subtotal + deliveryFee;
  const orderNumber = makeOrderNumber();

  const { data: order, error: orderError } = await supabaseAdmin
    .from("orders")
    .insert({
      order_number: orderNumber,
      user_id: user_id ?? null,
      customer_name: customer_name.trim(),
      phone: phone.trim(),
      address: address.trim(),
      city: city.trim(),
      notes: notes?.trim() || null,
      subtotal,
      discount: 0,
      delivery_fee: deliveryFee,
      total,
      payment_method: "cod",
      status: "new",
    })
    .select("id")
    .maybeSingle();

  if (orderError || !order) {
    return NextResponse.json({ error: "تعذر إنشاء الطلب" }, { status: 500 });
  }

  const { error: itemsError } = await supabaseAdmin
    .from("order_items")
    .insert(items.map((i) => ({ ...i, order_id: order.id })));

  if (itemsError) {
    return NextResponse.json({ error: "تعذر حفظ تفاصيل الطلب" }, { status: 500 });
  }

  await supabaseAdmin.from("order_status_history").insert({
    order_id: order.id,
    status: "new",
    note: "تم إنشاء الطلب",
  });

  await supabaseAdmin.from("notifications").insert({
    order_id: order.id,
    title: `طلب جديد ${orderNumber}`,
    body: `${customer_name.trim()} — ${formatEGP(total)} — ${city.trim()}`,
    audience: "admin",
    is_read: false,
  });

  await supabaseAdmin.from("notifications").insert({
    order_id: order.id,
    title: `تم استلام طلبك ${orderNumber}`,
    body: `سنقوم بالاتصال بك على ${phone.trim()} لتأكيد الطلب. الدفع عند الاستلام.`,
    audience: "customer",
    is_read: false,
  });

  for (const item of items) {
    const variant = variants.find((v) => v.id === item.variant_id);
    if (variant) {
      await supabaseAdmin
        .from("product_variants")
        .update({ stock: Math.max(0, variant.stock - item.quantity) })
        .eq("id", variant.id);
    }
  }

  return NextResponse.json({ id: order.id, order_number: orderNumber, total });
}

function formatEGP(value: number) {
  return `${value.toLocaleString("ar-EG", { maximumFractionDigits: 2 })} ج.م`;
}
