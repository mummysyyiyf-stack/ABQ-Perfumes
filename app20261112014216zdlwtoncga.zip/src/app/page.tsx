import Link from "next/link";
import { ArrowLeft, Sparkles, Truck, ShieldCheck, MessageCircle } from "lucide-react";
import ProductCard from "@/components/site/ProductCard";
import { getProducts, getVariants } from "@/lib/data";

export default async function HomePage() {
  const products = await getProducts();
  const variants = await getVariants(products.map((p) => p.id));

  const byProduct = (id: string) => variants.filter((v) => v.product_id === id);
  const featured = products.filter((p) => p.is_featured).slice(0, 6);
  const bestSellers = products.filter((p) => p.is_best_seller).slice(0, 4);
  const offers = products.filter((p) => p.is_offer).slice(0, 4);

  return (
    <div className="mx-auto max-w-7xl px-4">
      {/* Hero */}
      <section className="luxury-gradient relative overflow-hidden rounded-3xl px-6 py-20 text-center text-secondary-foreground md:py-28">
        <div className="absolute inset-0 opacity-25 [background:radial-gradient(circle_at_30%_20%,#c6a15b_0,transparent_45%),radial-gradient(circle_at_75%_70%,#c6a15b_0,transparent_40%)]" />
        <div className="relative">
          <p className="mb-3 text-xs uppercase tracking-[0.4em] text-primary">عطور ABQ</p>
          <h1 className="mx-auto max-w-3xl text-balance text-4xl font-extrabold leading-tight md:text-6xl">
            عالم من النفحات <span className="gold-text">الفاخرة</span>
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-sm leading-7 text-secondary-foreground/75 md:text-base">
            مجموعة مختارة بعناية من العطور الشرقية والغربية، بمكونات فاخرة وثبات يدوم، وبأسعار تبدأ من ٧٠ ج.م فقط.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Link
              href="/products"
              className="inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3 text-sm font-bold text-primary-foreground transition hover:opacity-90"
            >
              تسوق الآن
              <ArrowLeft className="h-4 w-4" />
            </Link>
            <Link
              href="/products?category=offers"
              className="inline-flex items-center gap-2 rounded-full border border-primary/60 px-7 py-3 text-sm font-bold text-primary transition hover:bg-primary/10"
            >
              <Sparkles className="h-4 w-4" />
              العروض الحالية
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="grid gap-4 py-10 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { icon: Truck, title: "شحن لكل مصر", desc: "توصيل سريع لجميع المحافظات" },
          { icon: ShieldCheck, title: "أصلي ١٠٠٪", desc: "منتجات أصلية مضمونة" },
          { icon: MessageCircle, title: "دعم واتساب", desc: "استشارة العطور عبر واتساب" },
          { icon: Sparkles, title: "ثبات طويل", desc: "نفحات تدوم حتى ١٦ ساعة" },
        ].map((f) => (
          <div
            key={f.title}
            className="flex items-start gap-3 rounded-2xl border border-border bg-card p-5"
          >
            <f.icon className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
            <div>
              <p className="text-sm font-bold">{f.title}</p>
              <p className="mt-1 text-xs leading-5 text-muted-foreground">{f.desc}</p>
            </div>
          </div>
        ))}
      </section>

      {/* Categories */}
      <section className="py-8">
        <h2 className="text-2xl font-extrabold">تسوق حسب الفئة</h2>
        <p className="mt-1 text-sm text-muted-foreground">اختر العطر المناسب لك من ABQ</p>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {[
            { slug: "men", label: "عطور رجالية", img: "abqm1" },
            { slug: "women", label: "عطور نسائية", img: "abqw1" },
            { slug: "unisex", label: "عطور مشتركة", img: "abqu1" },
            { slug: "luxury", label: "عطور فاخرة", img: "abql1" },
            { slug: "offers", label: "العروض", img: "abqo1" },
          ].map((c) => (
            <Link
              key={c.slug}
              href={`/products?category=${c.slug}`}
              className="group relative aspect-[3/4] overflow-hidden rounded-2xl border border-border"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={`https://picsum.photos/seed/${c.img}/600/800`}
                alt={c.label}
                className="h-full w-full object-cover opacity-70 transition duration-700 group-hover:scale-110 group-hover:opacity-90"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent" />
              <span className="absolute bottom-4 right-4 font-bold text-white">{c.label}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured */}
      <section className="py-8">
        <div className="flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-extrabold">العطور المميزة</h2>
            <p className="mt-1 text-sm text-muted-foreground">اختيارات ABQ هذا الموسم</p>
          </div>
          <Link href="/products" className="text-sm font-bold text-primary hover:underline">
            عرض الكل
          </Link>
        </div>
        <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {featured.map((p) => (
            <ProductCard key={p.id} product={p} variants={byProduct(p.id)} />
          ))}
        </div>
      </section>

      {/* Best sellers */}
      {bestSellers.length > 0 && (
        <section className="py-8">
          <h2 className="text-2xl font-extrabold">الأكثر مبيعًا</h2>
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {bestSellers.map((p) => (
              <ProductCard key={p.id} product={p} variants={byProduct(p.id)} />
            ))}
          </div>
        </section>
      )}

      {/* Offers */}
      {offers.length > 0 && (
        <section className="py-8">
          <h2 className="text-2xl font-extrabold">عروض خاصة</h2>
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {offers.map((p) => (
              <ProductCard key={p.id} product={p} variants={byProduct(p.id)} />
            ))}
          </div>
        </section>
      )}

      {/* Sizes & prices */}
      <section className="my-10 rounded-3xl border border-border bg-card p-8 text-center">
        <h2 className="text-2xl font-extrabold">الأحجام والأسعار</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          كل عطور ABQ متاحة بالأحجام التالية، ويمكنك اختيار الحجم المناسب قبل الإضافة للسلة.
        </p>
        <div className="mx-auto mt-8 grid max-w-3xl gap-4 sm:grid-cols-3">
          {[
            { size: "30 ML", price: 70, note: "للتجربة والاستخدام اليومي" },
            { size: "50 ML", price: 250, note: "الأكثر طلبًا" },
            { size: "100 ML", price: 400, note: "للاستخدام الطويل" },
          ].map((s) => (
            <div
              key={s.size}
              className="rounded-2xl border border-primary/40 bg-background p-6 transition hover:border-primary"
            >
              <p className="font-[family-name:var(--font-playfair)] text-2xl font-bold text-primary">
                {s.size}
              </p>
              <p className="mt-2 text-2xl font-extrabold">{s.price} ج.م</p>
              <p className="mt-1 text-xs text-muted-foreground">{s.note}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
