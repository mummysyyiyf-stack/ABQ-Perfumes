"use client";

import Link from "next/link";
import { Minus, Plus, ShoppingBag, Trash2, ArrowLeft } from "lucide-react";
import { useCart } from "@/components/CartProvider";
import { formatEGP } from "@/lib/format";

export default function CartPage() {
  const { lines, setQuantity, removeLine, subtotal, count, ready } = useCart();

  if (!ready) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-20 text-center text-sm text-muted-foreground">
        جارٍ تحميل السلة...
      </div>
    );
  }

  if (lines.length === 0) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-24 text-center">
        <ShoppingBag className="mx-auto h-16 w-16 text-muted-foreground/40" />
        <h1 className="mt-6 text-2xl font-extrabold">سلة المشتريات فارغة</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          لم تضف أي عطر بعد. اكتشف مجموعتنا من العطور الفاخرة.
        </p>
        <Link
          href="/products"
          className="mt-8 inline-flex items-center gap-2 rounded-full bg-secondary px-7 py-3 text-sm font-bold text-secondary-foreground transition hover:bg-primary hover:text-primary-foreground"
        >
          تصفح العطور
          <ArrowLeft className="h-4 w-4" />
        </Link>
      </div>
    );
  }

  const delivery = subtotal >= 1000 ? 0 : 50;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="text-3xl font-extrabold">سلة المشتريات</h1>
      <p className="mt-1 text-sm text-muted-foreground">{count} قطعة في السلة</p>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_360px]">
        <div className="space-y-4">
          {lines.map((line) => (
            <div
              key={line.variantId}
              className="flex flex-wrap items-center gap-4 rounded-2xl border border-border bg-card p-4"
            >
              <div className="h-24 w-20 overflow-hidden rounded-xl bg-muted">
                {line.imageUrl && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={line.imageUrl} alt={line.name} className="h-full w-full object-cover" />
                )}
              </div>

              <div className="min-w-40 flex-1">
                <p className="text-xs uppercase tracking-widest text-muted-foreground">ABQ</p>
                <p className="mt-0.5 font-bold">{line.name}</p>
                <p className="mt-1 text-xs text-muted-foreground">الحجم: {line.sizeLabel}</p>
                <p className="mt-1 text-sm font-bold text-primary">{formatEGP(line.price)}</p>
              </div>

              <div className="flex items-center gap-2 rounded-full border border-border px-2 py-1">
                <button
                  onClick={() => setQuantity(line.variantId, line.quantity + 1)}
                  className="rounded-full p-1 transition hover:bg-muted"
                  aria-label="زيادة"
                >
                  <Plus className="h-4 w-4" />
                </button>
                <span className="w-6 text-center text-sm font-bold">{line.quantity}</span>
                <button
                  onClick={() => setQuantity(line.variantId, line.quantity - 1)}
                  className="rounded-full p-1 transition hover:bg-muted"
                  aria-label="تقليل"
                >
                  <Minus className="h-4 w-4" />
                </button>
              </div>

              <p className="w-24 text-left font-extrabold">
                {formatEGP(line.price * line.quantity)}
              </p>

              <button
                onClick={() => removeLine(line.variantId)}
                className="rounded-full p-2 text-muted-foreground transition hover:bg-destructive/10 hover:text-destructive"
                aria-label="حذف"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>

        <aside className="h-fit rounded-2xl border border-border bg-card p-6">
          <h2 className="text-lg font-extrabold">ملخص الطلب</h2>
          <dl className="mt-5 space-y-3 text-sm">
            <div className="flex justify-between">
              <dt className="text-muted-foreground">المجموع الفرعي</dt>
              <dd className="font-bold">{formatEGP(subtotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted-foreground">رسوم التوصيل</dt>
              <dd className="font-bold">
                {delivery === 0 ? (
                  <span className="text-primary">مجاني</span>
                ) : (
                  formatEGP(delivery)
                )}
              </dd>
            </div>
            <div className="flex justify-between border-t border-border pt-3 text-base">
              <dt className="font-extrabold">الإجمالي</dt>
              <dd className="font-extrabold text-primary">{formatEGP(subtotal + delivery)}</dd>
            </div>
          </dl>

          {subtotal < 1000 && (
            <p className="mt-4 rounded-xl bg-muted p-3 text-xs text-muted-foreground">
              أضف {formatEGP(1000 - subtotal)} للحصول على شحن مجاني.
            </p>
          )}

          <Link
            href="/checkout"
            className="mt-6 flex items-center justify-center gap-2 rounded-full bg-secondary px-6 py-3 text-sm font-bold text-secondary-foreground transition hover:bg-primary hover:text-primary-foreground"
          >
            إتمام الطلب — الدفع عند الاستلام
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <Link
            href="/products"
            className="mt-3 block text-center text-xs font-semibold text-muted-foreground hover:text-primary"
          >
            متابعة التسوق
          </Link>
        </aside>
      </div>
    </div>
  );
}
