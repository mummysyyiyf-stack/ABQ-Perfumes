import { Suspense } from "react";
import AuthForms from "@/components/site/AuthForms";
import CustomerOrders from "@/components/site/CustomerOrders";

export const dynamic = "force-dynamic";

export default function AccountPage() {
  return (
    <Suspense fallback={<div className="py-20 text-center text-sm text-muted-foreground">جارٍ التحميل...</div>}>
      <div className="mx-auto max-w-3xl px-4 py-10">
        <AuthForms />
        <div className="mt-10">
          <h2 className="mb-4 text-lg font-extrabold">طلباتي</h2>
          <CustomerOrders />
        </div>
      </div>
    </Suspense>
  );
}
