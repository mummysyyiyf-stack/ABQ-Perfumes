"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Loader2, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { useCart } from "@/components/CartProvider";
import { useAuth } from "@/components/AuthProvider";
import { formatEGP } from "@/lib/format";

const CITIES = [
  "القاهرة",
  "الجيزة",
  "الإسكندرية",
  "المنصورة",
  "طنطا",
  "الزقازيق",
  "أسيوط",
  "سوهاج",
  "الأقصر",
  "أسوان",
  "بورسعيد",
  "السويس",
  "الإسماعيلية",
  "دمياط",
  "شبرا الخيمة",
];

export default function CheckoutPage() {
  const { lines, subtotal, clear, ready } = useCart();
  const { user } = useAuth();
  const router = useRouter();

  const [form, setForm] = useState({
    customer_name: "",
    phone: "",
    address: "",
    city: "",
    notes: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  const delivery = subtotal >= 1000 ? 0 : 50;

  const update = (key: string, value: string) => {
    setForm((f) => ({ ...f, [key]: value }));
    setErrors((e) => ({ ...e, [key]: "" }));
  };

  const validate = () => {
    const next: Record<string, string> = {};
    if (!form.customer_name.trim()) next.customer_name = "يرجى إدخال الاسم الكامل";
    if (!/^01[0-25]\d{8}$/.test(form.phone.replace(/\s/g, "")))
      next.phone = "رقم هاتف غير صحيح، مثال: 01012345678";
    if (!form.address.trim() || form.address.trim().length < 5)
      next.address = "يرجى إدخال عنوان مفصل";
    if (!form.city.trim()) next.city = "يرجى اختيار المدينة";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    if (lines.length === 0) {
      toast.error("السلة فارغة");
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          user_id: user?.id ?? null,
          lines: lines.map((l) => ({ variant_id: l.variantId, quantity: l.quantity })),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error ?? "تعذر إتمام الطلب");
        return;
      }
      clear();
      toast.success("تم استلام طلبك بنجاح");
      router.push(`/order/${data.id}`);
    } catch {
      toast.error("حدث خطأ أثناء إتمام الطلب");
    } finally {
      setSubmitting(false);
    }
  };

  if (ready && lines.length === 0) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-24 text-center">
        <h1 className="text-2xl font-extrabold">السلة فارغة</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          أضف عطورًا إلى السلة ثم أكمل طلبك.
        </p>
        <Link
          href="/products"
          className="mt-8 inline-block rounded-full bg-secondary px-7 py-3 text-sm font-bold text-secondary-foreground"
        >
          تصفح العطور
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="text-3xl font-extrabold">إتمام الطلب</h1>
      <p className="mt-1 text-sm text-muted-foreground">الدفع عند الاستلام — لا حاجة لبطاقة</p>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_380px]">
        <form
          onSubmit={submit}
          className="space-y-6 rounded-2xl border border-border bg-card p-6"
        >
          <div>
            <h2 className="text-lg font-extrabold">بيانات التوصيل</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              أدخل بياناتك بدقة حتى نتمكن من تأكيد الطلب معك.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label htmlFor="customer_name" className="mb-1.5 block text-sm font-semibold">
                الاسم الكامل *
              </label>
              <input
                id="customer_name"
                value={form.customer_name}
                onChange={(e) => update("customer_name", e.target.value)}
                aria-invalid={!!errors.customer_name}
                className="w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition focus:border-primary"
                placeholder="مثال: أحمد محمد"
              />
              {errors.customer_name && (
                <p className="mt-1.5 text-xs text-destructive">{errors.customer_name}</p>
              )}
            </div>

            <div>
              <label htmlFor="phone" className="mb-1.5 block text-sm font-semibold">
                رقم الهاتف *
              </label>
              <input
                id="phone"
                dir="ltr"
                value={form.phone}
                onChange={(e) => update("phone", e.target.value)}
                aria-invalid={!!errors.phone}
                className="w-full rounded-xl border border-input bg-background px-4 py-3 text-right text-sm outline-none transition focus:border-primary"
                placeholder="01012345678"
              />
              {errors.phone && <p className="mt-1.5 text-xs text-destructive">{errors.phone}</p>}
            </div>

            <div>
              <label htmlFor="city" className="mb-1.5 block text-sm font-semibold">
                المدينة *
              </label>
              <select
                id="city"
                value={form.city}
                onChange={(e) => update("city", e.target.value)}
                aria-invalid={!!errors.city}
                className="w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition focus:border-primary"
              >
                <option value="">اختر المدينة</option>
                {CITIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
              {errors.city && <p className="mt-1.5 text-xs text-destructive">{errors.city}</p>}
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="address" className="mb-1.5 block text-sm font-semibold">
                العنوان بالتفصيل *
              </label>
              <input
                id="address"
                value={form.address}
                onChange={(e) => update("address", e.target.value)}
                aria-invalid={!!errors.address}
                className="w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition focus:border-primary"
                placeholder="رقم المبنى، الشارع، الدور، الشقة، أقرب علامة مميزة"
              />
              {errors.address && <p className="mt-1.5 text-xs text-destructive">{errors.address}</p>}
            </div>

            <div className="sm:col-span-2">
              <label htmlFor="notes" className="mb-1.5 block text-sm font-semibold">
                ملاحظات (اختياري)
              </label>
              <textarea
                id="notes"
                value={form.notes}
                onChange={(e) => update("notes", e.target.value)}
                rows={3}
                className="w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition focus:border-primary"
                placeholder="وقت مناسب للتوصيل أو أي تعليمات إضافية"
              />
            </div>
          </div>

          <div className="flex items-center gap-2 rounded-xl bg-muted p-4 text-xs text-muted-foreground">
            <ShieldCheck className="h-4 w-4 shrink-0 text-primary" />
            يتم تأكيد الطلب هاتفيًا قبل الشحن. الدفع نقدًا عند الاستلام.
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="flex w-full items-center justify-center gap-2 rounded-full bg-secondary px-6 py-3.5 text-sm font-bold text-secondary-foreground transition hover:bg-primary hover:text-primary-foreground disabled:opacity-60"
          >
            {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            تأكيد الطلب — {formatEGP(subtotal + delivery)}
          </button>
        </form>

        <aside className="h-fit rounded-2xl border border-border bg-card p-6">
          <h2 className="text-lg font-extrabold">ملخص الطلب</h2>
          <div className="mt-4 space-y-3">
            {lines.map((l) => (
              <div key={l.variantId} className="flex items-center justify-between gap-3 text-sm">
                <div className="flex items-center gap-2">
                  <div className="h-12 w-10 overflow-hidden rounded-lg bg-muted">
                    {l.imageUrl && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={l.imageUrl} alt={l.name} className="h-full w-full object-cover" />
                    )}
                  </div>
                  <div>
                    <p className="text-xs font-bold">{l.name}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {l.sizeLabel} × {l.quantity}
                    </p>
                  </div>
                </div>
                <p className="font-bold">{formatEGP(l.price * l.quantity)}</p>
              </div>
            ))}
          </div>

          <dl className="mt-5 space-y-2.5 border-t border-border pt-4 text-sm">
            <div className="flex justify-between">
              <dt className="text-muted-foreground">المجموع الفرعي</dt>
              <dd className="font-bold">{formatEGP(subtotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted-foreground">التوصيل</dt>
              <dd className="font-bold">
                {delivery === 0 ? <span className="text-primary">مجاني</span> : formatEGP(delivery)}
              </dd>
            </div>
            <div className="flex justify-between border-t border-border pt-2.5 text-base">
              <dt className="font-extrabold">الإجمالي</dt>
              <dd className="font-extrabold text-primary">{formatEGP(subtotal + delivery)}</dd>
            </div>
          </dl>

          <Link
            href="/cart"
            className="mt-5 inline-flex items-center gap-2 text-xs font-semibold text-muted-foreground hover:text-primary"
          >
            <ArrowLeft className="h-3.5 w-3.5 rotate-180" />
            العودة إلى السلة
          </Link>
        </aside>
      </div>
    </div>
  );
}
