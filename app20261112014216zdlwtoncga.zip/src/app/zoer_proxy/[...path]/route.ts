import { NextRequest, NextResponse } from "next/server";

const POSTGREST_API_KEY = process.env.POSTGREST_API_KEY || "";
const NEXT_PUBLIC_ZOER_API = "https://api.zoer.ai";
const proxy_path = "zoer_proxy";
const RESPONSE_HEADERS_TO_REMOVE = [
  "connection",
  "keep-alive",
  "proxy-authenticate",
  "proxy-authorization",
  "te",
  "trailer",
  "transfer-encoding",
  "upgrade",
  "content-encoding",
  "content-length",
];

export async function GET(request: NextRequest) {
  return handleRequest(request);
}

export async function POST(request: NextRequest) {
  return handleRequest(request);
}

export async function PUT(request: NextRequest) {
  return handleRequest(request);
}

export async function DELETE(request: NextRequest) {
  return handleRequest(request);
}

export async function PATCH(request: NextRequest) {
  return handleRequest(request);
}

async function handleRequest(request: NextRequest) {
  const url = request.nextUrl;
  try {
    const requestedTargetPath = url.pathname.replace(`/${proxy_path}`, "") || "/";
    // The platform's presigned endpoint is registered without a trailing slash.
    // Normalize future SDK calls without reintroducing the upstream 308/error.
    const targetPath =
      requestedTargetPath === "/zapi/integration/presigned-url/"
        ? requestedTargetPath.slice(0, -1)
        : requestedTargetPath;

    const targetUrl = `${NEXT_PUBLIC_ZOER_API}${targetPath}${url.search}`;

    const headers = new Headers();

    request.headers.forEach((value, key) => {
      headers.set(key, value);
    });

    headers.set("x-zoer-auth", `${POSTGREST_API_KEY}`);
    headers.set("Postgrest-API-Key", `${POSTGREST_API_KEY}`);
    headers.delete("Authorization");
    // Keep browser-facing responses decodable after Next has handled upstream data.
    headers.set("accept-encoding", "identity");

    const host = NEXT_PUBLIC_ZOER_API.split("://")[1];
    if (host) {
      headers.set("Host", host);
    }

    let body: BodyInit | undefined;
    if (["POST", "PUT", "PATCH"].includes(request.method)) {
      body = await request.arrayBuffer();
    }

    const response = await fetch(targetUrl, {
      method: request.method,
      headers,
      body,
    });

    const responseHeaders = new Headers();
    response.headers.forEach((value, key) => {
      responseHeaders.set(key, value);
    });
    for (const header of RESPONSE_HEADERS_TO_REMOVE) {
      responseHeaders.delete(header);
    }

    return new NextResponse(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers: responseHeaders,
    });
  } catch (error) {
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
