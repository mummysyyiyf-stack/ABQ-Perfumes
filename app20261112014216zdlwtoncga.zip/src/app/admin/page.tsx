import AdminShell from "@/components/admin/AdminShell";
import AdminOverview from "@/components/admin/AdminOverview";

export const dynamic = "force-dynamic";

export default function AdminPage() {
  return (
    <AdminShell title="نظرة عامة">
      <AdminOverview />
    </AdminShell>
  );
}
