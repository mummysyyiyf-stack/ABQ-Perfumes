import AdminShell from "@/components/admin/AdminShell";
import AdminOrders from "@/components/admin/AdminOrders";

export const dynamic = "force-dynamic";

export default function AdminOrdersPage() {
  return (
    <AdminShell title="إدارة الطلبات">
      <AdminOrders />
    </AdminShell>
  );
}
