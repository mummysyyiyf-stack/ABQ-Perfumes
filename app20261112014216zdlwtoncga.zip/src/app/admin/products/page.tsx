import AdminShell from "@/components/admin/AdminShell";
import AdminProducts from "@/components/admin/AdminProducts";

export const dynamic = "force-dynamic";

export default function AdminProductsPage() {
  return (
    <AdminShell title="إدارة المنتجات">
      <AdminProducts />
    </AdminShell>
  );
}
