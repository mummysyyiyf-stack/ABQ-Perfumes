import AdminShell from "@/components/admin/AdminShell";
import AdminCategories from "@/components/admin/AdminCategories";

export const dynamic = "force-dynamic";

export default function AdminCategoriesPage() {
  return (
    <AdminShell title="إدارة الفئات">
      <AdminCategories />
    </AdminShell>
  );
}
