import Link from "next/link";
import { notFound } from "next/navigation";
import { headers } from "next/headers";
import { CheckCircle2, MessageCircle, Phone, Truck } from "lucide-react";
import { supabaseAdmin } from "@/integrations/supabase/server";
import { formatEGP, formatDate } from "@/lib/format";
import { ORDER_STATUS_LABELS, type Order, type OrderItem } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function OrderPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;

  const { data: order } = await supabaseAdmin
    .from("orders")
    .select(
      "id,order_number,user_id,customer_name,phone,address,city,notes,subtotal,discount,delivery_fee,total,payment_method,status,created_at",
    )
    .eq("id", id)
    .maybeSingle();

  if (!order) notFound();

  const { data: items } = await supabaseAdmin
    .from("order_items")
    .select(
      "id,product_id,variant_id,product_name,variant_label,unit_price,quantity,line_total,image_url",
    )
    .eq("order_id", id);

  const typedOrder = order as Order;
  const typedItems = (items ?? []) as OrderItem[];

  const headerList = await headers();
  const authToken = headerList.get("authorization")?.replace("Bearer ", "");
  let isOwner = !typedOrder.user_id;
  if (typedOrder.user_id && authToken) {
    const { data: userData } = await supabaseAdmin.auth.getUser(authToken);
    isOwner = userData?.user?.id === typedOrder.user_id;
  }

  const whatsappNumber = "201000000000";
  const whatsappMessage = encodeURIComponent(
    `مرحبًا ABQ، بخصوص الطلب ${typedOrder.order_number}`,
  );

  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <div className="rounded-3xl border border-border bg-card p-8 text-center">
        <CheckCircle2 className="mx-auto h-16 w-16 text-primary" />
        <p className="mt-4 font-[family-name:var(--font-playfair)] text-2xl font-bold tracking-[0.35em] gold-text">
          ABQ
        </p>
        <h1 className="mt-4 text-3xl font-extrabold">تم استلام طلبك بنجاح</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          سنقوم بالاتصال بك خلال ٢٤ ساعة لتأكيد الطلب. الدفع عند الاستلام.
        </p>

        <div className="mt-6 inline-flex flex-col items-center rounded-2xl border border-primary/40 bg-primary/5 px-8 py-4">
          <span className="text-xs text-muted-foreground">رقم الطلب</span>
          <span dir="ltr" className="mt-1 font-[family-name:var(--font-playfair)] text-2xl font-bold text-primary">
            {typedOrder.order_number}
          </span>
          <span className="mt-2 rounded-full bg-muted px-3 py-1 text-xs font-bold">
            {ORDER_STATUS_LABELS[typedOrder.status]}
          </span>
        </div>

        {isOwner ? (
          <div className="mt-8 grid gap-4 text-right sm:grid-cols-2">
            <div className="rounded-2xl border border-border p-4">
              <p className="text-xs font-bold text-primary">بيانات التوصيل</p>
              <p className="mt-2 text-sm font-bold">{typedOrder.customer_name}</p>
              <p dir="ltr" className="mt-1 text-right text-sm text-muted-foreground">{typedOrder.phone}</p>
              <p className="mt-1 text-sm text-muted-foreground">
                {typedOrder.address}، {typedOrder.city}
              </p>
            </div>
            <div className="rounded-2xl border border-border p-4">
              <p className="text-xs font-bold text-primary">تفاصيل الطلب</p>
              <p className="mt-2 text-sm text-muted-foreground">
                تاريخ الطلب: {formatDate(typedOrder.created_at)}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">طريقة الدفع: الدفع عند الاستلام</p>
              <p className="mt-1 flex items-center gap-1 text-sm text-muted-foreground">
                <Truck className="h-4 w-4 text-primary" /> التوصيل خلال ٢-٤ أيام عمل
              </p>
            </div>
          </div>
        ) : (
          <p className="mt-8 rounded-2xl border border-border bg-muted/40 p-4 text-xs text-muted-foreground">
            سجل الدخول لعرض بيانات التوصيل الكاملة. يمكنك متابعة حالة طلبك من صفحة حسابي.
          </p>
        )}

        <div className="mt-8 overflow-hidden rounded-2xl border border-border text-right">
          <div className="grid grid-cols-[1fr_auto_auto] gap-3 bg-muted px-4 py-3 text-xs font-bold text-muted-foreground">
            <span>المنتج</span>
            <span>السعر</span>
            <span>الإجمالي</span>
          </div>
          {typedItems.map((item) => (
            <div
              key={item.id}
              className="grid grid-cols-[1fr_auto_auto] items-center gap-3 border-t border-border px-4 py-3 text-sm"
            >
              <div className="flex items-center gap-3">
                <div className="h-12 w-10 overflow-hidden rounded-lg bg-muted">
                  {item.image_url && (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={item.image_url} alt={item.product_name} className="h-full w-full object-cover" />
                  )}
                </div>
                <div>
                  <p className="font-bold">{item.product_name}</p>
                  <p className="text-xs text-muted-foreground">
                    {item.variant_label} × {item.quantity}
                  </p>
                </div>
              </div>
              <span className="text-muted-foreground">{formatEGP(item.unit_price)}</span>
              <span className="font-bold">{formatEGP(item.line_total)}</span>
            </div>
          ))}
          <dl className="space-y-2 border-t border-border bg-muted/40 px-4 py-4 text-sm">
            <div className="flex justify-between">
              <dt className="text-muted-foreground">المجموع الفرعي</dt>
              <dd className="font-bold">{formatEGP(typedOrder.subtotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted-foreground">رسوم التوصيل</dt>
              <dd className="font-bold">
                {Number(typedOrder.delivery_fee) === 0 ? (
                  <span className="text-primary">مجاني</span>
                ) : (
                  formatEGP(typedOrder.delivery_fee)
                )}
              </dd>
            </div>
            <div className="flex justify-between border-t border-border pt-2 text-base">
              <dt className="font-extrabold">الإجمالي</dt>
              <dd className="font-extrabold text-primary">{formatEGP(typedOrder.total)}</dd>
            </div>
          </dl>
        </div>

        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <a
            href={`https://wa.me/${whatsappNumber}?text=${whatsappMessage}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-secondary px-6 py-3 text-sm font-bold text-secondary-foreground transition hover:bg-primary hover:text-primary-foreground"
          >
            <MessageCircle className="h-4 w-4" />
            التواصل عبر واتساب
          </a>
          {isOwner && (
            <a
              href={`tel:${typedOrder.phone}`}
              className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 text-sm font-bold transition hover:border-primary"
            >
              <Phone className="h-4 w-4" />
              اتصال بخدمة العملاء
            </a>
          )}
          <Link
            href="/products"
            className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3 text-sm font-bold transition hover:border-primary"
          >
            العودة إلى المتجر
          </Link>
        </div>
      </div>
    </div>
  );
}
