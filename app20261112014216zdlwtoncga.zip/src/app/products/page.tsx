import Link from "next/link";
import { getCategories, getProducts, getVariants } from "@/lib/data";
import ProductCard from "@/components/site/ProductCard";
import { CATEGORY_LABELS } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string; q?: string }>;
}) {
  const { category, q } = await searchParams;
  const categories = await getCategories();
  const products = await getProducts({
    categorySlug: category,
    search: q,
  });
  const variants = await getVariants(products.map((p) => p.id));
  const byProduct = (id: string) => variants.filter((v) => v.product_id === id);

  const current = category && category !== "all" ? category : "all";

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <nav className="text-xs text-muted-foreground">
        <Link href="/" className="hover:text-primary">الرئيسية</Link> / العطور
      </nav>

      <h1 className="mt-3 text-3xl font-extrabold">
        {current === "all"
          ? q
            ? `نتائج البحث عن "${q}"`
            : "كل عطور ABQ"
          : CATEGORY_LABELS[current] ?? "العطور"}
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        {products.length} منتج متاح
      </p>

      <div className="mt-6 flex flex-wrap gap-2">
        <Link
          href="/products"
          className={`rounded-full border px-4 py-2 text-xs font-bold transition ${
            current === "all"
              ? "border-primary bg-primary text-primary-foreground"
              : "border-border hover:border-primary"
          }`}
        >
          الكل
        </Link>
        {categories.map((c) => (
          <Link
            key={c.id}
            href={`/products?category=${c.slug}`}
            className={`rounded-full border px-4 py-2 text-xs font-bold transition ${
              current === c.slug
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border hover:border-primary"
            }`}
          >
            {c.name}
          </Link>
        ))}
      </div>

      {products.length === 0 ? (
        <div className="mt-16 rounded-2xl border border-dashed border-border p-16 text-center">
          <p className="text-lg font-bold">لا توجد نتائج</p>
          <p className="mt-2 text-sm text-muted-foreground">
            جرّب كلمة بحث أخرى أو تصفح جميع العطور.
          </p>
          <Link
            href="/products"
            className="mt-6 inline-block rounded-full bg-secondary px-6 py-2.5 text-sm font-bold text-secondary-foreground"
          >
            عرض كل العطور
          </Link>
        </div>
      ) : (
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} variants={byProduct(p.id)} />
          ))}
        </div>
      )}
    </div>
  );
}
