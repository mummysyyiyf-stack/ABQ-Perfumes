import { notFound } from "next/navigation";
import { getProductBySlug, getVariants } from "@/lib/data";
import ProductDetail from "@/components/site/ProductDetail";

export const dynamic = "force-dynamic";

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const variants = await getVariants([product.id]);
  return <ProductDetail product={product} variants={variants} />;
}
