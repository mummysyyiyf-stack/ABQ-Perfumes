"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Heart, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/components/AuthProvider";
import { formatEGP } from "@/lib/format";
import type { Product, ProductVariant } from "@/lib/types";

export default function WishlistPage() {
  const { user } = useAuth();
  const [ids, setIds] = useState<string[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [variants, setVariants] = useState<ProductVariant[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const key = user ? `abq_wishlist_${user.id}` : "abq_wishlist_guest";
    let raw = "";
    try {
      raw = window.localStorage.getItem(key) ?? "";
    } catch {
      // ignore
    }
    const list: string[] = raw ? JSON.parse(raw) : [];
    setIds(list);

    const load = async () => {
      setLoading(true);
      if (list.length > 0) {
        const { data } = await supabase
          .from("products")
          .select(
            "id,name,slug,brand,description,category_id,gender,top_notes,heart_notes,base_notes,longevity,image_url,rating,review_count,is_featured,is_best_seller,is_offer,discount_percent,is_active",
          )
          .in("id", list);
        const typed = (data ?? []) as Product[];
        setProducts(typed);
        if (typed.length > 0) {
          const { data: v } = await supabase
            .from("product_variants")
            .select("id,product_id,size_label,volume_ml,price_egp,stock,is_active")
            .in("product_id", typed.map((p) => p.id));
          setVariants((v ?? []) as ProductVariant[]);
        }
      } else {
        setProducts([]);
        setVariants([]);
      }
      setLoading(false);
    };
    load();
  }, [user]);

  const remove = (id: string) => {
    const key = user ? `abq_wishlist_${user.id}` : "abq_wishlist_guest";
    const raw = window.localStorage.getItem(key);
    const list: string[] = raw ? JSON.parse(raw) : [];
    const next = list.filter((x) => x !== id);
    window.localStorage.setItem(key, JSON.stringify(next));
    setIds(next);
    setProducts((p) => p.filter((x) => x.id !== id));
    if (user) {
      supabase.from("wishlist_items").delete().eq("product_id", id).eq("user_id", user.id);
    }
    toast.success("تمت الإزالة من قائمة الأمنيات");
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="text-3xl font-extrabold">قائمة الأمنيات</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        {ids.length} عطر محفوظ
      </p>

      {loading ? (
        <p className="py-20 text-center text-sm text-muted-foreground">جارٍ التحميل...</p>
      ) : products.length === 0 ? (
        <div className="mt-10 rounded-2xl border border-dashed border-border p-16 text-center">
          <Heart className="mx-auto h-14 w-14 text-muted-foreground/30" />
          <p className="mt-5 text-lg font-bold">قائمة الأمنيات فارغة</p>
          <p className="mt-2 text-sm text-muted-foreground">
            احفظ العطور التي تعجبك لتعود إليها لاحقًا.
          </p>
          <Link
            href="/products"
            className="mt-7 inline-block rounded-full bg-secondary px-7 py-3 text-sm font-bold text-secondary-foreground"
          >
            تصفح العطور
          </Link>
        </div>
      ) : (
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {products.map((p) => {
            const pVariants = variants.filter((v) => v.product_id === p.id);
            const min = pVariants.length
              ? Math.min(...pVariants.map((v) => Number(v.price_egp)))
              : 0;
            return (
              <article
                key={p.id}
                className="overflow-hidden rounded-2xl border border-border bg-card"
              >
                <Link href={`/products/${p.slug}`} className="block aspect-[4/5] overflow-hidden bg-muted">
                  {p.image_url && (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={p.image_url}
                      alt={`عطر ${p.name}`}
                      className="h-full w-full object-cover transition duration-500 hover:scale-105"
                    />
                  )}
                </Link>
                <div className="p-4">
                  <Link href={`/products/${p.slug}`} className="font-bold hover:text-primary">
                    {p.name}
                  </Link>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {pVariants.map((v) => v.size_label).join(" · ") || "ABQ"}
                  </p>
                  <p className="mt-2 text-sm font-bold text-primary">
                    يبدأ من {formatEGP(min)}
                  </p>
                  <button
                    onClick={() => remove(p.id)}
                    className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground transition hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                    إزالة
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
